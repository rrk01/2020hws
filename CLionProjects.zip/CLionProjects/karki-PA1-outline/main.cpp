#include <iostream> //preprocessor directive for input/output streams
using namespace std; //standard namespace

int main() { //program starts here
    /* -> PA1 Outline
     * >Print name and ID
     * >Display menu with three options
     * 1. Almost always 99
     * 2. Always 3
     * 3. Exit
     * >If user input not equals 1,2, or 3, re-display menu above
     * >If 1 is entered
     *  start loop from 0 to 99{
     *      >if number is less than 10, multiply it by 10
     *      >declare new ints temp1 and temp2
     *      >temp1 = n1/10
     *      >temp2 = n1%10
     *      >n2 = temp2*10 + temp1. n2 becomes Swapped digits. Print n2.
     *      >int n3 = n1-n2. Print n3.
     *      >if n3 is negative, multiply it by -1. Print n3.
     *      >if n3 < 10, multiply by 10. Print n3.
     *      >int n4 becomes swapped version of n3. Print n4
     *      >int result = n3+n4. Print result
     *  >if result == 99, print "Congratulations". else print "something went wrong".
     * >if 2 is entered
     *  >user inputs a number n
     *  >number = n*2, double number. Print
     *  >number += 9, add 9 to number. Print
     *  >number -= 3, subtract 3 from number. Print
     *  >number /= 2, divide number by 2. Print
     *  >result = number-n, subtract original number from current number. Print
     *  >if result == 3, print "congratulations". else print "something went wrong"
     * >if 3 is entered
     *  >print 'good bye' and end program
     */
    return 0; //program ends here
} //end main