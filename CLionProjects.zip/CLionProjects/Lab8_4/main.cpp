// declare the necessary header files.

#include <iostream>

#include <string>

#include <vector>

using namespace std;

// declare the main function.

int main()

{

// declare a vector.

    vector<string> words;

    vector<int> counts;

// declare variables.

    int size;

    string str;

    cin >> size;

// start the for loop.

    for(int i = 0; i < size; ++i)

    {

// input string.

        cin >> str;

        words.push_back(str);

    }

// start the for loop.

    for(int i = 0; i < size; ++i)

    {

        int count = 0;

// start the for loop.

        for(int j = 0; j < words.size(); ++j)

        {

// check the condition.

            if(words[j] == words[i])

            {

                count++;

            }

        }

        counts.push_back(count);

    }

// start the for loop.

    for(int i = 0; i < size; ++i)

    {

// display result on console.

        cout << words[i] << " " << counts[i] << endl;

    }

    return 0;

}