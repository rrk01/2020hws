#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    ifstream in("studentIn.txt");
    if(in.is_open()) {
        ofstream out("studentOut.txt");
        int id;
        string name;
        while(in >> id) {
            getline(in, name);
            out << id << "\t" << name << endl;
        }
        out.close();
        in.close();
    } else {
        cout << "studentIn.txt does not exist!" << endl;
    }
    return 0;
}