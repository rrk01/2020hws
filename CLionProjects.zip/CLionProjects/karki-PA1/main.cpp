#include <iostream>
#include <fstream>
using namespace std;

int main() {
    int userIn = 1;
    cout << "Name: Ryan Karki" << endl; //intro menu
    cout << "ID: 107867709" << endl;
    while(userIn >= 1 && userIn <= 4 && userIn != 3) { //If an invalid number is entered, the menu shows up again
        cout << "Enter a number." << endl;
        cout << "1. Almost always 99" << endl;
        cout << "2. Always 3" << endl;
        cout << "3. Exit" << endl;
        cout << "4. Always 3 from file" << endl;
        cin >> userIn; //user selects menu choice
        switch (userIn) {
            case 1:
                int n1; //number to be modified each loop
                int n2; //placeholders for steps vv
                int n3;
                int n4;
                int result; //should be 99 at the end of the loop
                int temp1; //placeholder for tens place
                int temp2; //placeholder for ones place
                for (int i = 0; i <= 99; i++) { //turning most numbers from 0 to 99 into 99
                    n1 = i;
                    if (n1 < 10) //if n1 is less than 10
                        n1 *= 10; //n1 is multiplied by 10
                    temp1 = n1 / 10; //separating the digits of n1
                    temp2 = n1 % 10;
                    n2 = temp2 * 10 + temp1; //n2 = n1 but with swapped digits
                    cout << n1 << " reverses to make " << n2 << endl; //Print current progress
                    n3 = n1 - n2;
                    if (n3 < 0)
                        n3 *= -1; //n3 becomes the absolute value of the difference of n2 and n1
                    cout << "Absolute value of " << n1 << " - " << n2 << " = " << n3 << endl;
                    if (n3 < 10)
                        n3 *= 10;
                    temp1 = n3 / 10; //separating the digits of n3
                    temp2 = n3 % 10;
                    n4 = temp2 * 10 + temp1; //generating result (hopefully 99)
                    cout << n3 << " reverses to make " << n4 << endl;
                    result = n3 + n4; //result should be 99 most of the time
                    if (result == 99)
                        cout << "Congrats! " << n1 << " + " << n4 << " = " << result << endl << endl;
                    else
                        cout << "This method does not work on 0 or multiples of 11! " << n1 << " + " << n4 << " = "
                             << result << endl << endl;
                }
                break;
            case 2:
                int userIn2;
                cout << "Pick a number." << endl;
                cin >> userIn2; //user picks a random number
                int three; //should end up being 3
                cout << "Okay! Let's start! Your number is " << userIn2 << endl; //some math magics vv
                three = userIn2 * 2;
                cout << "We've doubled your number. Your number is now " << three << endl;
                three += 9;
                cout << "We've added 9 to your number. Your number is now " << three << endl;
                three -= 3;
                cout << "We've subtracted 3 from your number. Your number is now " << three << endl;
                three /= 2;
                cout << "We've divided your number by 2. Your number is now " << three << endl;
                three -= userIn2;
                cout << "We've subtracted your original number of " << userIn2
                     << " from your current number. Your number is now " << three << endl;
                if (three == 3)
                    cout << "3 = 3! Congratulations. Thanks for playing!" << endl;
                else
                    cout << "Oops. Something went wrong. You weren't supposed to see this.";
                break;
            case 3:
                cout << "Goodbye." << endl;
                break;
            case 4: {
                int userFileIn;
                ifstream myfile("num2b3.txt");
                if (myfile.is_open()) {
                    while (myfile >> userFileIn) {
                        cout << "Your number from file is " << userFileIn << endl;
                    }
                }
                myfile.close();
                int three2; //should end up being 3
                three2 = userFileIn * 2; //some math magics vv
                cout << "We've doubled your number. Your number is now " << three2 << endl;
                three2 += 9;
                cout << "We've added 9 to your number. Your number is now " << three2 << endl;
                three2 -= 3;
                cout << "We've subtracted 3 from your number. Your number is now " << three2 << endl;
                three2 /= 2;
                cout << "We've divided your number by 2. Your number is now " << three2 << endl;
                three2 -= userFileIn;
                cout << "We've subtracted your original number of " << userFileIn
                     << " from your current number. Your number is now " << three2 << endl;
                if (three2 == 3)
                    cout << "3 = 3! Congratulations. Thanks for playing!" << endl;
                else
                    cout << "Oops. Something went wrong. You weren't supposed to see this.";
                break;
            }
            default:
                break;
        }
    }
    return 0;
}