//
// Created by ryanr on 11/19/2019.
//

#ifndef DATASTRUCTURESFINAL_CSVREADER_H
#define DATASTRUCTURESFINAL_CSVREADER_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "ActorActress.h"
#include "Pictures.h"
#include "global.h"

using namespace std;

class CSVReader {
public:
    static void readActorActress(vector<ActorActress> &toStore);
    static void readPictures(vector<Pictures> &toStore);
};
#endif //DATASTRUCTURESFINAL_CSVREADER_H
