//
// Created by ryanr on 12/3/2019.
//

#ifndef DATASTRUCTURESFINAL_ACTORACTRESSDATABASE_H
#define DATASTRUCTURESFINAL_ACTORACTRESSDATABASE_H

#include "ActorActress.h"
#include "global.h"

struct ActorActressDatabase{
    static void addActorActress(vector<ActorActress> &toStore); //Add an ActorActress to the database
    static void partialSearchActorActress(vector<ActorActress> &toSearch); //Search for an ActorActress in the database
    static int findIdPosition(vector<ActorActress> &toSearch, int idToSearch); //Returns the position of the ID to search
    /*static void swap(ActorActress &object1, ActorActress &object2);
    static void heapify(vector<ActorActress> arr, int n, int i); //code taken from https://www.geeksforgeeks.org/heap-sort/
    static void heapSort(vector<ActorActress> arr, int n); //code taken from https://www.geeksforgeeks.org/heap-sort/
    */
};
#endif //DATASTRUCTURESFINAL_ACTORACTRESSDATABASE_H
