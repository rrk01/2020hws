//
// Created by ryanr on 11/19/2019.
//

#ifndef DATASTRUCTURESFINAL_PICTURES_H
#define DATASTRUCTURESFINAL_PICTURES_H

#include <iostream>
#include <string>

using namespace std;

class Pictures {
private:
    string name;
    string year;
    string nominations;
    string ratings;
    string duration;
    string genre1;
    string genre2;
    string release;
    string metacritic;
    string synopsis;
    int id;
public:
    int getId() const;

    void setId(int id);

public:
    Pictures(const string &name, const string &year, const string &nominations, const string &ratings,
             const string &duration, const string &genre1, const string &genre2, const string &release,
             const string &metacritic, const string &synopsis, int id) : name(name), year(year), nominations(nominations),
                                                                 ratings(ratings), duration(duration), genre1(genre1),
                                                                 genre2(genre2), release(release),
                                                                 metacritic(metacritic), synopsis(synopsis), id(id) {}

    const string &getName() const;

    void setName(const string &name);

    const string &getYear() const;

    void setYear(const string &year);

    const string &getNominations() const;

    void setNominations(const string &nominations);

    const string &getRatings() const;

    void setRatings(const string &ratings);

    const string &getDuration() const;

    void setDuration(const string &duration);

    const string &getGenre1() const;

    void setGenre1(const string &genre1);

    const string &getGenre2() const;

    void setGenre2(const string &genre2);

    const string &getRelease() const;

    void setRelease(const string &release);

    const string &getMetacritic() const;

    void setMetacritic(const string &metacritic);

    const string &getSynopsis() const;

    void setSynopsis(const string &synopsis);

    friend ostream & operator << (ostream &out, const Pictures &a);

    friend bool operator< (const Pictures &picture1, const Pictures &picture2);

    friend bool operator> (const Pictures &picture1, const Pictures &picture2);

    friend bool operator<= (const Pictures &picture1, const Pictures &picture2);

    friend bool operator>= (const Pictures &picture1, const Pictures &picture2);
};
#endif //DATASTRUCTURESFINAL_PICTURES_H
