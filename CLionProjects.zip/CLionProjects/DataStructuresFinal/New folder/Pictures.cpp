//
// Created by ryanr on 11/19/2019.
//

#include "Pictures.h"

const string &Pictures::getName() const {
    return name;
}

void Pictures::setName(const string &name) {
    Pictures::name = name;
}

const string &Pictures::getYear() const {
    return year;
}

void Pictures::setYear(const string &year) {
    Pictures::year = year;
}

const string &Pictures::getNominations() const {
    return nominations;
}

void Pictures::setNominations(const string &nominations) {
    Pictures::nominations = nominations;
}

const string &Pictures::getRatings() const {
    return ratings;
}

void Pictures::setRatings(const string &ratings) {
    Pictures::ratings = ratings;
}

const string &Pictures::getDuration() const {
    return duration;
}

void Pictures::setDuration(const string &duration) {
    Pictures::duration = duration;
}

const string &Pictures::getGenre1() const {
    return genre1;
}

void Pictures::setGenre1(const string &genre1) {
    Pictures::genre1 = genre1;
}

const string &Pictures::getGenre2() const {
    return genre2;
}

void Pictures::setGenre2(const string &genre2) {
    Pictures::genre2 = genre2;
}

const string &Pictures::getRelease() const {
    return release;
}

void Pictures::setRelease(const string &release) {
    Pictures::release = release;
}

const string &Pictures::getMetacritic() const {
    return metacritic;
}

void Pictures::setMetacritic(const string &metacritic) {
    Pictures::metacritic = metacritic;
}

const string &Pictures::getSynopsis() const {
    return synopsis;
}

void Pictures::setSynopsis(const string &synopsis) {
    Pictures::synopsis = synopsis;
}

//Overloaded operator << to print easier
ostream & operator << (ostream &out, const Pictures &a)
{
    out << "Name:" << a.name << endl
        << "Year: " << a.year << endl
        << "Nominations: " << a.nominations << endl
        << "Ratings: " << a.ratings << endl
        << "Durations: " << a.duration << endl
        << "Genre1: " << a.genre1 << endl
        << "Genre2: " << a.genre2 << endl
        << "Release: " << a.release << endl
        << "Metacritic: " << a.metacritic << endl
        << "Synopsis: " << a.synopsis << endl
        << "ID: " << a.id << endl;
    return out;
}

bool operator< (const Pictures &picture1, const Pictures &picture2) {
    return picture1.getName() < picture2.getName();
}

bool operator> (const Pictures &picture1, const Pictures &picture2) {
    return picture1.getName() > picture2.getName();
}

bool operator<= (const Pictures &picture1, const Pictures &picture2) {
    return picture1.getName() <= picture2.getName();
}

bool operator>= (const Pictures &picture1, const Pictures &picture2) {
    return picture1.getName() >= picture2.getName();
}

int Pictures::getId() const {
    return id;
}

void Pictures::setId(int id) {
    Pictures::id = id;
}
