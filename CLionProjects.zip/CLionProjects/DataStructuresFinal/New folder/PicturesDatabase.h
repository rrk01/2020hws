//
// Created by ryanr on 11/19/2019.
//

#ifndef DATASTRUCTURESFINAL_PICTURESDATABASE_H
#define DATASTRUCTURESFINAL_PICTURESDATABASE_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include "CSVReader.h"
#include "ActorActress.h"
#include "Pictures.h"
#include "global.h"

using namespace std;

struct PicturesDatabase{
    static void addPictures(vector<Pictures> &toStore); //Add a Pictures object to the database
    static void partialSearchPictures(vector<Pictures> &toSearch); //Search for a Pictures object in the database
    static int findIdPosition(vector<Pictures> &toSearch, int idToSearch); //Returns the position of the ID to search
    //static void swap(Pictures &object1, Pictures &object2);
    //static void heapify(vector<Pictures> arr, int n, int i);
    //static void heapSort(vector<Pictures> arr, int n);
};

#endif //DATASTRUCTURESFINAL_PICTURESDATABASE_H
