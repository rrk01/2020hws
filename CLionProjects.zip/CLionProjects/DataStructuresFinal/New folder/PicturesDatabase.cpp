//
// Created by ryanr on 11/19/2019.
//

#include "PicturesDatabase.h"

void PicturesDatabase::addPictures(vector<Pictures> &toStore) {
    string tempName, tempYear, tempNominations, tempRatings, tempDuration, tempGenre1, tempGenre2, tempRelease, tempMeta, tempSynopsis;

    cout << "Please enter a name:" << endl;
    cin >> tempName;
    cout << endl << "Please enter a year:" << endl;
    cin >> tempYear;
    cout << endl << "Please enter nominations:" << endl;
    cin >> tempNominations;
    cout << endl << "Please enter a rating:" << endl;
    cin >> tempRatings;
    cout << endl << "Please enter a duration:" << endl;
    cin >> tempDuration;
    cout << endl << "Please enter a primary genre:" << endl;
    cin >> tempGenre1;
    cout << endl << "Please enter a secondary genre:" << endl;
    cin >> tempGenre2;
    cout << endl << "Please enter a release date:" << endl;
    cin >> tempRelease;
    cout << endl << "Please enter a Metacritic rating:" << endl;
    cin >> tempMeta;
    cout << endl << "Please enter a synopsis:" << endl;
    cin.ignore();
    getline(cin, tempSynopsis);

    toStore.emplace_back(Pictures(tempName, tempYear, tempNominations, tempRatings, tempDuration, tempGenre1, tempGenre2, tempRelease, tempMeta, tempSynopsis,globalCounter));
    globalCounter ++;

    cout << "Pictures" << endl << endl << toStore.at(toStore.size()-1) << endl << endl << "successfully added!" << endl << endl;
}

//This function prints all objects containing the search term.
void PicturesDatabase::partialSearchPictures(vector<Pictures> &toSearch) {
    int choice; //menu selection
    string userSearch; //string user wants to find
    int countFound = 0; //counts the number of successful searches
    cout << "Please pick a field to search:" << endl
         << "1. Name" << endl
         << "2. Year" << endl
         << "3. Nominations" << endl
         << "4. Ratins" << endl
         << "5. Duration" << endl
         << "6. Genre (primary)" << endl
         << "7. Genre (secondary)" << endl
         << "8. Release" << endl
         << "9. Metacritic" << endl
         << "10. Synopsis" << endl;
    cin >> choice;
    switch(choice) {
        case 1:
            cout << "Please enter a name or part of a name to search." << endl;
            cin.ignore();
            getline(cin, userSearch); //user input search term
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getName().find(userSearch) < string::npos) { //if string exists
                    cout << toSearch[i] << endl; //print the object
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 2:
            cout << "Please enter a year or part of a year to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getYear().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 3:
            cout << "Please enter a nomination or part of a nomination to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getNominations().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 4:
            cout << "Please enter a rating or part of a rating to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if (toSearch[i].getRatings().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 5:
            cout << "Please enter a duration or part of a duration to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getDuration().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 6:
            cout << "Please enter a genre or part of a genre to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getGenre1().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 7:
            cout << "Please enter a genre or part of a genre to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getGenre2().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 8:
            cout << "Please enter a release or part of a release to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getRelease().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 9:
            cout << "Please enter a metacritic rating of part of a metacritic rating to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getMetacritic().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 10:
            cout << "Please enter a synopsis or part of a synopsis to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getSynopsis().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        default:
            break;
    }
}

int PicturesDatabase::findIdPosition(vector<Pictures> &toSearch, int idToSearch) { //linear search
    for(int i = 0; i < toSearch.size(); i ++) {
        if(toSearch[i].getId() == idToSearch) {
            return i;
        }
    }
    return -1;
}

/*
void PicturesDatabase::swap(Pictures &object1, Pictures &object2) {
    Pictures tempObject = object1;
    object1 = object2;
    object2 = tempObject;
}

void PicturesDatabase::heapify(vector<Pictures> arr, int n, int i) {
    int largest = i; // Initialize largest as root
    int l = 2*i + 1; // left = 2*i + 1
    int r = 2*i + 2; // right = 2*i + 2

    // If left child is larger than root
    if (l < n && arr[l] > arr[largest])
        largest = l;

    // If right child is larger than largest so far
    if (r < n && arr[r] > arr[largest])
        largest = r;

    // If largest is not root
    if (largest != i)
    {
        swap(arr[i], arr[largest]);

        // Recursively heapify the affected sub-tree
        heapify(arr, n, largest);
    }
}

void PicturesDatabase::heapSort(vector<Pictures> arr, int n)
{
    // Build heap (rearrange array)
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    // One by one extract an element from heap
    for (int i=n-1; i>=0; i--)
    {
        // Move current root to end
        swap(arr[0], arr[i]);

        // call max heapify on the reduced heap
        heapify(arr, i, 0);
    }
}
 */