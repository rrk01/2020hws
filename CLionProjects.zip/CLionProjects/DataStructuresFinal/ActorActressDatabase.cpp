//
// Created by ryanr on 12/3/2019.
//

#include "ActorActressDatabase.h"

void ActorActressDatabase::addActorActress(vector<ActorActress> &toStore) {
    string tempYear, tempAward, tempWinner, tempName, tempFilm;

    cout << "Please enter a year:" << endl;
    cin >> tempYear;
    cout << endl << "Please enter an award:" << endl;
    cin >> tempAward;
    cout << endl << "Please enter a winner:" << endl;
    cin >> tempWinner;
    cout << endl << "Please enter a name:" << endl;
    cin >> tempName;
    cout << endl << "Please enter a film:" << endl;
    cin >> tempFilm;

    toStore.emplace_back(ActorActress(tempYear,tempAward,tempWinner,tempName,tempFilm,globalCounter));
    globalCounter ++;

    cout << "ActorActress" << endl << endl << toStore.at(toStore.size()-1) << endl << "successfully added!" << endl << endl;
}

//This function prints all objects containing the search term.
void ActorActressDatabase::partialSearchActorActress(vector<ActorActress> &toSearch) {
    int choice; //menu selection
    string userSearch; //string user wants to find
    int countFound = 0; //counts the number of successful searches
    cout << "Please pick a field to search:" << endl
         << "1. Year" << endl
         << "2. Award" << endl
         << "3. Winner" << endl
         << "4. Name" << endl
         << "5. Film" << endl;
    cin >> choice;
    switch(choice) {
        case 1:
            cout << "Please enter a year (ex. 1987) or part of a year (198) to find." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getYear().find(userSearch) < string::npos) { //if string exists
                    cout << toSearch[i] << endl; //print the object
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 2:
            cout << "Please enter an award or part of an award." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getAward().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 3:
            cout << "Please enter 0 or 1 to search. 1 indicates winner, 0 indicates no winner." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getWinner().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 4:
            cout << "Please enter a name of part of a name to search." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if (toSearch[i].getName().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        case 5:
            cout << "Please enter the name or part of the name of a film." << endl;
            cin.ignore();
            getline(cin, userSearch);
            for(int i = 0; i < toSearch.size(); i ++) {
                if(toSearch[i].getFilm().find(userSearch) < string::npos) {
                    cout << toSearch[i] << endl;
                    countFound ++;
                }
            }
            if(countFound == 0) {
                cout << "No matches for this search term!" << endl;
                break;
            }
            break;
        default:
            break;
    }
}


int ActorActressDatabase::findIdPosition(vector<ActorActress> &toSearch, int idToSearch) {
    for(int i = 0; i < toSearch.size(); i ++) {
        if(toSearch[i].getId() == idToSearch) {
            return i;
        }
    }
    return -1;
}

/*
void ActorActressDatabase::swap(ActorActress &object1, ActorActress &object2) {
    ActorActress tempObject = object1;
    object1 = object2;
    object2 = tempObject;
}

void ActorActressDatabase::heapify(vector<ActorActress> arr, int n, int i) {
    int largest = i; // Initialize largest as root
    int l = 2*i + 1; // left = 2*i + 1
    int r = 2*i + 2; // right = 2*i + 2

    // If left child is larger than root
    if (l < n && arr[l] > arr[largest])
        largest = l;

    // If right child is larger than largest so far
    if (r < n && arr[r] > arr[largest])
        largest = r;

    // If largest is not root
    if (largest != i)
    {
        swap(arr[i], arr[largest]);

        // Recursively heapify the affected sub-tree
        heapify(arr, n, largest);
    }
}

void ActorActressDatabase::heapSort(vector<ActorActress> arr, int n)
{
    // Build heap (rearrange array)
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    // One by one extract an element from heap
    for (int i=n-1; i>=0; i--)
    {
        // Move current root to end
        swap(arr[0], arr[i]);

        // call max heapify on the reduced heap
        heapify(arr, i, 0);
    }
}
 */