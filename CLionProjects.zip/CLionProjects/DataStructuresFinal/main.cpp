#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <string>
#include "CSVReader.h"
#include "ActorActress.h"
#include "ActorActressDatabase.h"
#include "Pictures.h"
#include "PicturesDatabase.h"
#include "global.h"

using namespace std;

int main() {
    vector<ActorActress> actData; //data structure for ActorActress
    vector<Pictures> pictData; //data structure for Pictures
    vector<ActorActress> nomData; //data structure for Nominations

    int choice = 1; //user selection for all menus
    string userModification;
    //int n; //used for heapsort

    while (true){
        cout << "Menu:" << endl;
        cout << "1. Read in from file" << endl;
        cout << "2. Add in a record" << endl;
        cout << "3. Search/modify a record" << endl;
        cout << "4. Sort a database by name" << endl;
        cout << "5. Print database" << endl;
        cout << "6. Exit program" << endl;
        cin >> choice;
        switch(choice){
            case 1: //Read in from file
                cout << "Choose an option:" << endl
                     << "1. ActorActress" << endl
                     << "2. Pictures" << endl
                     << "3. Nominations" << endl
                     << "Pick any other number to go back to main menu." << endl;
                cin >> choice;
                switch(choice) {
                    case 1: //ActorActress
                        CSVReader::readActorActress(actData); //reads in from file
                        make_heap(actData.begin(),actData.end()); //turns into heap
                        cout << "There are " << actData.size() << " total entries." << endl;
                        break;
                    case 2: //Pictures
                        CSVReader::readPictures(pictData); //reads in from file
                        make_heap(pictData.begin(),pictData.end()); //turns into heap
                        cout << "There are " << pictData.size() << " total entries." << endl;
                        break;
                    case 3: //Nominations
                        CSVReader::readActorActress(nomData); //reads in from file
                        make_heap(nomData.begin(),nomData.end()); //turns into heap
                        cout << "There are " << nomData.size() << " total entries." << endl;
                        break;
                    default:
                        break;
                }
                break;
            case 2: //Add in a record
                cout << "Choose a database to add to:" << endl
                     << "1. ActorActress" << endl
                     << "2. Pictures" << endl
                     << "3. Nominations" << endl
                     << "Pick any other number to go back to main menu." << endl;
                cin >> choice;
                switch(choice) {
                    case 1:
                        ActorActressDatabase::addActorActress(actData);
                        break;
                    case 2:
                        PicturesDatabase::addPictures(pictData);
                        break;
                    case 3:
                        ActorActressDatabase::addActorActress(nomData);
                        break;
                    default:
                        break;
                }
                break;
            case 3: //Search and modify a record
                cout << "Choose a type of database to search:" << endl
                     << "1. ActorActress" << endl
                     << "2. Pictures" << endl
                     << "3. Nominations" << endl
                     << "Pick any other number to go back to main menu." << endl;
                cin >> choice;
                cin.ignore();
                switch(choice) {
                    case 1:
                        ActorActressDatabase::partialSearchActorActress(actData);
                        cout << "Please select the ID of the ActorActress to modify:" << endl;
                        cin >> choice;
                        if(ActorActressDatabase::findIdPosition(actData,choice) == -1) {
                            cout << "Invalid ID!" << endl;
                            break;
                        }
                        cout << "Please select a field to modify:" << endl
                             << "1. Year" << endl
                             << "2. Award" << endl
                             << "3. Winner" << endl
                             << "4. Name" << endl
                             << "5. Film" << endl;
                        cin >> choice;
                        switch(choice) {
                            case 1:
                                cout << "Please enter a new year:" << endl;
                                cin >> userModification;
                                actData[ActorActressDatabase::findIdPosition(actData,choice)].setYear(userModification);
                                break;
                            case 2:
                                cout << "Please enter a new award:" << endl;
                                cin >> userModification;
                                actData[ActorActressDatabase::findIdPosition(actData,choice)].setAward(userModification);
                                break;
                            case 3:
                                cout << "Please enter a new winner:" << endl;
                                cin >> userModification;
                                actData[ActorActressDatabase::findIdPosition(actData,choice)].setWinner(userModification);
                                break;
                            case 4:
                                cout << "Please enter a new name:" << endl;
                                cin >> userModification;
                                actData[ActorActressDatabase::findIdPosition(actData,choice)].setName(userModification);
                                break;
                            case 5:
                                cout << "Please enter a new film:" << endl;
                                cin >> userModification;
                                actData[ActorActressDatabase::findIdPosition(actData,choice)].setFilm(userModification);
                                break;
                            default:
                                cout << "Invalid choice!";
                                break;
                        }
                        cout << "Entry ID " << choice << " successfully modified!" << endl;
                        break;
                    case 2:
                        PicturesDatabase::partialSearchPictures(pictData);
                        cout << "Please select the ID of the Pictures to modify:" << endl;
                        cin >> choice;
                        if(PicturesDatabase::findIdPosition(pictData,choice) == -1) {
                            cout << "Invalid ID!" << endl;
                            break;
                        }
                        cout << "Please select a field to modify:" << endl
                             << "1. Name" << endl
                             << "2. Year" << endl
                             << "3. Nominations" << endl
                             << "4. Ratings" << endl
                             << "5. Duration" << endl
                             << "6. Genre (primary)" << endl
                             << "7. Genre (secondary)" << endl
                             << "8. Release" << endl
                             << "9. Metacritic rating" << endl
                             << "10. Synopsis" << endl;
                        cin >> choice;
                        switch(choice) {
                            case 1:
                                cout << "Please enter a new name:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setName(userModification);
                                break;
                            case 2:
                                cout << "Please enter a new year:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setYear(userModification);
                                break;
                            case 3:
                                cout << "Please enter new nominations:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setNominations(userModification);
                                break;
                            case 4:
                                cout << "Please enter a new rating:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setRatings(userModification);
                                break;
                            case 5:
                                cout << "Please enter a new duration:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setDuration(userModification);
                                break;
                            case 6:
                                cout << "Please enter a new primary genre:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setGenre1(userModification);
                                break;
                            case 7:
                                cout << "Please enter a new secondary genre:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setGenre2(userModification);
                                break;
                            case 8:
                                cout << "Please enter a new release month:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setRelease(userModification);
                                break;
                            case 9:
                                cout << "Please enter a new Metacritic rating:" << endl;
                                cin >> userModification;
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setMetacritic(userModification);
                                break;
                            case 10:
                                cout << "Please enter a new synopsis:" << endl;
                                cin.ignore();
                                getline(cin, userModification);
                                pictData[PicturesDatabase::findIdPosition(pictData,choice)].setSynopsis(userModification);
                                break;
                            default:
                                cout << "Invalid choice!";
                                break;
                        }
                        cout << "Entry ID " << choice << " successfully modified!" << endl;
                        break;
                    case 3:
                        ActorActressDatabase::partialSearchActorActress(nomData);
                        cout << "Please select the ID of the Nominations to modify:" << endl;
                        cin >> choice;
                        if(ActorActressDatabase::findIdPosition(nomData,choice) == -1) {
                            cout << "Invalid ID!" << endl;
                            break;
                        }
                        cout << "Please select a field to modify:" << endl
                             << "1. Year" << endl
                             << "2. Award" << endl
                             << "3. Winner" << endl
                             << "4. Name" << endl
                             << "5. Film" << endl;
                        cin >> choice;
                        switch(choice) {
                            case 1:
                                cout << "Please enter a new year:" << endl;
                                cin >> userModification;
                                nomData[ActorActressDatabase::findIdPosition(nomData,choice)].setYear(userModification);
                                break;
                            case 2:
                                cout << "Please enter a new award:" << endl;
                                cin >> userModification;
                                nomData[ActorActressDatabase::findIdPosition(nomData,choice)].setAward(userModification);
                                break;
                            case 3:
                                cout << "Please enter a new winner:" << endl;
                                cin >> userModification;
                                nomData[ActorActressDatabase::findIdPosition(nomData,choice)].setWinner(userModification);
                                break;
                            case 4:
                                cout << "Please enter a new name:" << endl;
                                cin >> userModification;
                                nomData[ActorActressDatabase::findIdPosition(nomData,choice)].setName(userModification);
                                break;
                            case 5:
                                cout << "Please enter a new film:" << endl;
                                cin >> userModification;
                                nomData[ActorActressDatabase::findIdPosition(nomData,choice)].setFilm(userModification);
                                break;
                            default:
                                cout << "Invalid choice!";
                                break;
                        }
                        cout << "Entry ID " << choice << " successfully modified!" << endl;
                    default:
                        break;
                }
                break;
            case 4: //Sort by name
                cout << "Please choose a database to sort:" << endl
                     << "1. ActorActress" << endl
                     << "2. Pictures" << endl
                     << "3. Nominations" << endl;
                cin >> choice;
                switch(choice) {
                    case 1:
                        //n = sizeof(actData)/sizeof(actData[0]);
                        //ActorActressDatabase::heapSort(actData, n);
                        make_heap(actData.begin(), actData.end());
                        sort_heap(actData.begin(), actData.end());
                        cout << "Sort successful!" << endl;
                        break;
                    case 2:
                        //n = pictData.size();
                        //PicturesDatabase::heapSort(pictData, n);
                        make_heap(pictData.begin(), pictData.end());
                        sort_heap(pictData.begin(), pictData.end());
                        cout << "Sort successful!" << endl;
                        break;
                    case 3:
                        //n = sizeof(nomData)/sizeof(nomData[0]);
                        //ActorActressDatabase::heapSort(actData, n);
                        make_heap(nomData.begin(), nomData.end());
                        sort_heap(nomData.begin(), nomData.end());
                        cout << "Sort successful!" << endl;
                        break;
                    default:
                        break;
                }
                break;
            case 5: //Print a database
                cout << "Please choose a database to print:" << endl
                     << "1. ActorActress" << endl
                     << "2. Pictures" << endl
                     << "3. Nominations" << endl
                     << "Pick any other number to go back to main menu." << endl;
                cin >> choice;
                switch(choice) {
                    case 1:
                        for(int i = 0; i < actData.size(); i ++)
                            cout << actData[i] << endl;
                        break;
                    case 2:
                        for(int i = 0; i < pictData.size(); i ++)
                            cout << pictData[i] << endl;
                        break;
                    case 3:
                        for(int i = 0; i < nomData.size(); i ++)
                            cout << nomData[i] << endl;
                        break;
                    case 4:
                        break;
                    default:
                        break;
                }
                break;
            case 6: //Exit program
                cout << "Bye!";
                exit(1);
            default:
                cout << "Please select a different option." << endl;
                choice = 1;
                break;
        }
    }
    return 0;
}