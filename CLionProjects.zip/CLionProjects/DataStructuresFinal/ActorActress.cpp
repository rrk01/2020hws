//
// Created by ryanr on 11/18/2019.
//

#include "ActorActress.h"

const string &ActorActress::getYear() const {
    return year;
}

void ActorActress::setYear(const string &year) {
    ActorActress::year = year;
}

const string &ActorActress::getAward() const {
    return award;
}

void ActorActress::setAward(const string &award) {
    ActorActress::award = award;
}

const string &ActorActress::getWinner() const {
    return winner;
}

void ActorActress::setWinner(const string &winner) {
    ActorActress::winner = winner;
}

const string &ActorActress::getName() const {
    return name;
}

void ActorActress::setName(const string &name) {
    ActorActress::name = name;
}

const string &ActorActress::getFilm() const {
    return film;
}

void ActorActress::setFilm(const string &film) {
    ActorActress::film = film;
}

bool operator< (const ActorActress &actor1, const ActorActress &actor2) {
    return actor1.getName() < actor2.getName();
}

bool operator> (const ActorActress &actor1, const ActorActress &actor2) {
    return actor1.getName() > actor2.getName();
}

bool operator<= (const ActorActress &actor1, const ActorActress &actor2) {
    return actor1.getName() <= actor2.getName();
}

bool operator>= (const ActorActress &actor1, const ActorActress &actor2) {
    return actor1.getName() >= actor2.getName();
}

//Overloaded operator << to print easier
ostream & operator << (ostream &out, const ActorActress &a)
{
    out << "Year:\t" << a.year << endl
        << "Award:\t" << a.award << endl
        << "Winner:\t" << a.winner << endl
        << "Name:\t" << a.name << endl
        << "Film:\t" << a.film << endl
        << "ID:\t" << a.id << endl;
    return out;
}

int ActorActress::getId() const {
    return id;
}

void ActorActress::setId(int id) {
    ActorActress::id = id;
}
