//
// Created by ryanr on 12/11/2019.
//

#ifndef DATASTRUCTURESFINAL_GLOBAL_H
#define DATASTRUCTURESFINAL_GLOBAL_H

extern int globalCounter; //number to generate unique ID's for entries

#endif //DATASTRUCTURESFINAL_GLOBAL_H
