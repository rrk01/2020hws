//
// Created by ryanr on 11/19/2019.
//

#include "CSVReader.h"

void CSVReader::readActorActress(vector<ActorActress> &toStore) {
    int counter = 0;
    string line;
    string tempYear, tempAward, tempWinner, tempName, tempFilm;
    string fileName;

    cout << "Please enter file name:" << endl;
    cin >> fileName;

    ifstream fin;
    fin.open(fileName);
    if(fin.fail()){
        cout << "Input file opening failed.\n";
        exit(1);
    }
    getline(fin, line);

    while(getline(fin, line)) {
        stringstream s(line);

        getline(s, tempYear, ',');
        getline(s, tempAward, ',');
        getline(s, tempWinner, ',');
        getline(s, tempName, ',');
        getline(s, tempFilm, ',');

        toStore.emplace_back(ActorActress(tempYear,tempAward,tempWinner,tempName,tempFilm,globalCounter));
        counter ++;
        globalCounter ++;
    }

    fin.close();

    cout << "File " << fileName << " successfully read!" << endl;
    cout << "There are " << counter << " new entries." << endl;

}

void CSVReader::readPictures(vector<Pictures> &toStore) {
    int counter = 0;
    string line;
    string tempName, tempYear, tempNominations, tempRatings, tempDuration, tempGenre1, tempGenre2, tempRelease, tempMeta, tempSynopsis;
    string fileName;

    ifstream fin;

    cout << "Please enter file name:" << endl;
    cin >> fileName;

    fin.open(fileName);
    if(fin.fail()){
        cout << "Input file opening failed.\n";
        exit(1);
    }
    getline(fin, line);

    while(getline(fin, line)) {
        stringstream s(line);

        getline(s, tempName, ',');
        getline(s, tempYear, ',');
        getline(s, tempNominations, ',');
        getline(s, tempRatings, ',');
        getline(s, tempDuration, ',');
        getline(s, tempGenre1, ',');
        getline(s, tempGenre2, ',');
        getline(s, tempRelease, ',');
        getline(s, tempMeta, ',');
        getline(s, tempSynopsis, ',');

        toStore.emplace_back(Pictures(tempName, tempYear, tempNominations, tempRatings, tempDuration, tempGenre1, tempGenre2, tempRelease, tempMeta, tempSynopsis, globalCounter));
        counter ++;
        globalCounter ++;
    }

    fin.close();

    cout << "File " << fileName << " successfully read!" << endl;
    cout << "There are " << counter << " new entries." << endl;

}