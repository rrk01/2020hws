//
// Created by ryanr on 11/18/2019.
//

#ifndef DATASTRUCTURESFINAL_ACTORACTRESS_H
#define DATASTRUCTURESFINAL_ACTORACTRESS_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include "global.h"

using namespace std;

class ActorActress {
private:
    string year;
    string award;
    string winner;
    string name;
    string film;
    int id;
public:
    int getId() const;

    void setId(int id);

    const string &getYear() const;

    void setYear(const string &year);

    const string &getAward() const;

    void setAward(const string &award);

    const string &getWinner() const;

    void setWinner(const string &winner);

    const string &getName() const;

    void setName(const string &name);

    const string &getFilm() const;

    void setFilm(const string &film);

    friend ostream & operator << (ostream &out, const ActorActress &a);

    friend bool operator< (const ActorActress &actor1, const ActorActress &actor2);

    friend bool operator> (const ActorActress &actor1, const ActorActress &actor2);

    friend bool operator<= (const ActorActress &actor1, const ActorActress &actor2);

    friend bool operator>= (const ActorActress &actor1, const ActorActress &actor2);

    ActorActress(const string &year, const string &award, const string &winner, const string &name, const string &film, int id)
            : year(year), award(award), winner(winner), name(name), film(film), id(id){}
};

#endif //DATASTRUCTURESFINAL_ACTORACTRESS_H
