//
// Created by ryanr on 12/11/2019.
//

#include "global.h"

int globalCounter = 0;