#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;
int main() {
    int arr[8];
    int count = 0;
    ifstream infile("in.txt");
    while(infile >> arr[count])
        count ++;
    infile.close();
    int init = arr[0];
    for(int i = 1; i < 9; i ++) {
        if(arr[i] < 40)
            arr[0] -= round(arr[0]*.1);
        else if(arr[i] >= 40 && arr[i] < 60)
            arr[0] -= round(arr[0]*.3);
        else if(arr[i] >= 60 && arr[i] < 70)
            arr[0] -= round(arr[0]*.5);
        else if(arr[i] >= 70 && arr[i] < 80)
            arr[0] -= round(arr[0]*.6);
        else
            arr[0] -= round(arr[0]*.4);
        cout << arr[0] << endl;
    }
    cout << "Estimated sale is " << init-arr[0] << " plants.";
    return 0;
}