//
// Created by ryanr on 7/26/2019.
//
#include <iostream>
#include<fstream>
#include<vector>
using namespace std;

void readIn(ifstream &infile, vector<int> &vec)
{
    int c;
    while(infile>>c)//reading from file
    {//and adding to vector
        vec.push_back(c);
    }
}
//to print vector
void print(vector<int> vec)
{
    for(int i=0;i<vec.size();i++)
        cout<<vec.at(i)<<" ";
    cout<<endl;
}
//method to reverse the order of vector
vector<int> sortDesc(vector<int> vec)
{
    //reversing the order
    vector<int> reversal;
    for(int i=vec.size()-1;i>=0;i--) {
        reversal.push_back(vec.at(i));
    }
    return reversal;
}