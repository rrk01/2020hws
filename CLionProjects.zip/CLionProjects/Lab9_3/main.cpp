#include<iostream>
#include<fstream>
#include<vector>
#include "functions.h"
using namespace std;

int main() {
    char filename[30];
    cin>>filename;
    vector<int> v;
    ifstream f(filename);
    //calling reading method
    readIn(f,v);
    f.close();
    print(v);
    print(v);
    //now creating new vector
    vector<int> y = sortDesc(v);
    print(y);
    return 0;
}