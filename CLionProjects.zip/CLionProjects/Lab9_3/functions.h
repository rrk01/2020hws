//
// Created by ryanr on 7/26/2019.
//

#ifndef LAB9_3_FUNCTIONS_H
#define LAB9_3_FUNCTIONS_H
#include <vector>
#include <fstream>
using namespace std;

void readIn(ifstream &infile, vector<int> &vec);

void print(vector<int> vec);

vector<int> sortDesc(vector<int> vec);
#endif //LAB9_3_FUNCTIONS_H
