//
// Created by ryanr on 11/5/2019.
//

#ifndef BATTLESHIP_GAME_H
#define BATTLESHIP_GAME_H

#include "Player.h"
#include <sstream>
#include <fstream>
#include <cstring>
class Game{
private:
    bool over = false; //terminates program if true
public:
    int tempCoords[2]; //array variable for coordToInt function
    Player player1; //human player
    Player player2; //AI player
    Game() {
        tempCoords[0] = 0;
        tempCoords[1] = 0;
    }

    bool isOver() const {
        return over;
    }

    void setIsOver() { //checks whether either player has all ships sunk
        if(player1.getSunkCount() == 5) {
            cout << "You Lose!" << endl;
            over = true;
        }else if(player2.getSunkCount() == 5) {
            cout << "You Win!" << endl;
            over = true;
        }
    }

    // reads ships from a CSV file.
    // playerShips[]: list of player's ships to be modified.
    // fileName: input csv file.
    void readShipsFromFile(Ship playerShips[], string fileName);
};
#endif //BATTLESHIP_GAME_H
