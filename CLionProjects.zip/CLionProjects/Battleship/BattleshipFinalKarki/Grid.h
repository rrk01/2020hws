//
// Created by ryanr on 11/4/2019.
//

#ifndef BATTLESHIP_GRID_H
#define BATTLESHIP_GRID_H

#include <iostream>
#include "Ship.h"
struct Grid{
    char grid[11][11]; //10x10 board with edges labeling indices
    Grid() {
        for(int i = 0; i < 11; i ++) {
            for(int j = 0; j < 11; j ++) {
                grid[i][j] = 126;
            }
        }
        for(int i = 1; i < 11; i ++) {
            grid[0][i] = i+64;
        }
        for(int i = 1; i < 11; i ++) {
            grid[i][0] = i+48;
        }
    }
    void printGrid(); //prints 2d array
};
#endif //BATTLESHIP_GRID_H
