//
// Created by ryanr on 11/4/2019.
//

#include "Grid.h"
using namespace std;

void Grid::printGrid() {
    for(int i = 0; i < 11; i ++) {
        for(int j = 0; j < 11; j ++) {
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
}