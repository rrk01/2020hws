#include <iostream>
#include <time.h>
#include "Game.h"
#include "Grid.h"
#include "Player.h"
#include "Ship.h"
using namespace std;

int main() {
    srand(time(NULL)); //new random seed every second
    Game battleship;

    battleship.readShipsFromFile(battleship.player1.ships, "ship_placement9_bad.csv");
    battleship.player1.placeShipsFromFile(); //player1 is human and imports ships from file
    battleship.player2.placeShipsRandomly(); //player2 is AI, so places ships randomly

    /*battleship.player2.attack.printGrid();
        cout << endl;
        battleship.player2.defense.printGrid();
        cout << endl;*/ //uncomment to view AI grids
    battleship.player1.attack.printGrid();
    cout << endl;
    battleship.player1.defense.printGrid();
    cout << endl;

    while(!battleship.isOver()) {

        battleship.player1.guessManually(battleship.player2); //human player guess

        battleship.setIsOver();

        cout << endl;
        /*battleship.player2.attack.printGrid();
        cout << endl;
        battleship.player2.defense.printGrid();
        cout << endl;*/ //uncomment to view AI grids
        battleship.player1.attack.printGrid();
        cout << endl;
        battleship.player1.defense.printGrid();
        cout << endl;

        battleship.player2.guessRandomly(battleship.player1); //AI player guess

        cout << endl;
        /*battleship.player2.attack.printGrid();
        cout << endl;
        battleship.player2.defense.printGrid();
        cout << endl;*/ //uncomment to view AI grids
        battleship.player1.attack.printGrid();
        cout << endl;
        battleship.player1.defense.printGrid();
        cout << endl;

        battleship.setIsOver();
    }

    return 0;
}