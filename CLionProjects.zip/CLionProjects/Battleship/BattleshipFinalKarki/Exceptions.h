//
// Created by ryanr on 12/1/2019.
//

#ifndef BATTLESHIP_EXCEPTIONS_H
#define BATTLESHIP_EXCEPTIONS_H

//Exceptions
class InvalidCoordException{ //Valid coordinates range from A1 to J10. Anything outside of this is invalid.
};
class ShipOBException{ //Thrown when a ship is placed outside of the grid. i.e. horizontal carrier on the right edge.
};
class ShipOverlapException{ //Thrown when two ships overlap
};
class InvalidShipNameException{ //Thrown when an invalid ship name is read from file
};
class InvalidOrientationException{ //Thrown when orientation is neither "H" nor "V"
};

#endif //BATTLESHIP_EXCEPTIONS_H
