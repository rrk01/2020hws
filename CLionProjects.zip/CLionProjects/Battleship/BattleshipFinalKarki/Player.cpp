//
// Created by ryanr on 11/5/2019.
//

#include "Player.h"

void Player::placeShipsFromFile() {
    try {
        for (int i = 0; i < 5; i++) { //traverse ships[]
            for (int j = 0; j < ships[i].getLength(); j++) { //loop to place symbols on grid
                if (ships[i].getOrient() == "H") { //if horizontal
                    if(ships[i].getYCoor() + j > 11) //checks to see if ship goes off the grid
                        throw ShipOBException();
                    else if(defense.grid[ships[i].getXCoor()][ships[i].getYCoor() + j] != '~') //checks ship overlap
                        throw ShipOverlapException();

                    defense.grid[ships[i].getXCoor()][ships[i].getYCoor() + j] = ships[i].getSymbol(); //place ship at starting coord then move from left to right
                } else if (ships[i].getOrient() == "V") {
                    if(ships[i].getXCoor() + j > 11) //checks to see if ship goes off the grid
                        throw ShipOBException();
                    else if(defense.grid[ships[i].getXCoor() + j][ships[i].getYCoor()] != '~') //checks ship overlap
                        throw ShipOverlapException();

                    defense.grid[ships[i].getXCoor() + j][ships[i].getYCoor()] = ships[i].getSymbol(); //place ship at starting coord then move from top to bottom
                }else{ //if orientation is neither H nor V, throw this exception
                    throw InvalidOrientationException();
                }
                ships[i].setPlaced(true);
            }
        }
    }catch(ShipOBException) {
        cout << "Ship Out of Bounds Exception";
        exit(1);
    }
    catch(ShipOverlapException) {
        cout << "Ship Overlap Exception";
        exit(1);
    }
    catch(InvalidOrientationException) {
        cout << "Invalid Orientation Exception";
        exit(1);
    }
}

void Player::placeShipsRandomly() {
    int shipsPlaced = 0; //counter for while loop

    //generating constants
    ships[0].setType("Carrier");
    ships[0].setLength(5);
    ships[0].setSymbol('C');

    ships[1].setType("Battleship");
    ships[1].setLength(4);
    ships[1].setSymbol('B');

    ships[2].setType("Cruiser");
    ships[2].setLength(3);
    ships[2].setSymbol('Z');

    ships[3].setType("Submarine");
    ships[3].setLength(3);
    ships[3].setSymbol('S');

    ships[4].setType("Destroyer");
    ships[4].setLength(2);
    ships[4].setSymbol('D');

    //random variable declarations
    int randOrientInt;
    int randX;
    int randY;

    while(shipsPlaced < 5) {
        //generate random ship placements
        randOrientInt = rand() % 2;
        randX = rand() % 10 + 1;
        randY = rand() % 10 + 1;
        if (randOrientInt == 0)
            ships[shipsPlaced].setOrient("H");
        else
            ships[shipsPlaced].setOrient("V");
        ships[shipsPlaced].setXCoor(randX);
        ships[shipsPlaced].setYCoor(randY);

        for (int j = 0; j < ships[shipsPlaced].getLength(); j++) { //loop to place symbols on grid
            if (ships[shipsPlaced].getOrient() == "H") { //if horizontal
                if (ships[shipsPlaced].getYCoor() + j > 11 ||
                    defense.grid[ships[shipsPlaced].getXCoor()][ships[shipsPlaced].getYCoor() + j] !=
                    '~') {  //checks to see if ship goes off the grid, or if ships overlap
                    for (int k = 0; k < j; k++) { //replace wrongly placed ship with blank spaces
                        defense.grid[ships[shipsPlaced].getXCoor()][ships[shipsPlaced].getYCoor() + k] = '~';
                    }
                    break;
                }

                defense.grid[ships[shipsPlaced].getXCoor()][ships[shipsPlaced].getYCoor() +
                                                            j] = ships[shipsPlaced].getSymbol(); //place ship at starting coord then move from left to right
                if (j == ships[shipsPlaced].getLength() - 1)
                    ships[shipsPlaced].setPlaced(true);
            } else if (ships[shipsPlaced].getOrient() == "V") {
                if (ships[shipsPlaced].getXCoor() + j > 11 ||
                    defense.grid[ships[shipsPlaced].getXCoor() + j][ships[shipsPlaced].getYCoor()] !=
                    '~') { //checks to see if ship goes off the grid or if ships overlap
                    for (int k = 0; k < j; k++) { //replace wrongly placed ship with blank spaces
                        defense.grid[ships[shipsPlaced].getXCoor() + k][ships[shipsPlaced].getYCoor()] = '~';
                    }
                    break;
                }

                defense.grid[ships[shipsPlaced].getXCoor() +
                             j][ships[shipsPlaced].getYCoor()] = ships[shipsPlaced].getSymbol(); //place ship at starting coord then move from top to bottom
                if (j == ships[shipsPlaced].getLength() - 1)
                    ships[shipsPlaced].setPlaced(true);
            }
        }
        if (ships[shipsPlaced].isPlaced())
            shipsPlaced++;
    }
}

void Player::printShips() {
    for(int i = 0; i < 5; i ++) {
        cout << ships[i].getType() << " "
             << ships[i].getYCoor() << " "
             << ships[i].getXCoor() << " "
             << ships[i].getOrient() << endl;
    }
}

bool Player::guessRandomly(Player &opponent) {
    int randX = rand()%10+1;
    int randY = rand()%10+1;
    char shipSymbol;
    int i;
    while(true) {
        if (opponent.defense.grid[randX][randY] == '~') { //if guess lands over water, return false
            attack.grid[randX][randY] = 'o';
            cout << "Computer has missed!" << endl;
            return false;
        }else if (attack.grid[randX][randY] == 'x' || attack.grid[randX][randY] == 'o'){ //if guess lands on a previous guess, guess again
            continue;
        }else if(opponent.defense.grid[randX][randY] == 'C' ||
                 opponent.defense.grid[randX][randY] == 'B' ||
                 opponent.defense.grid[randX][randY] == 'Z' ||
                 opponent.defense.grid[randX][randY] == 'S' ||
                 opponent.defense.grid[randX][randY] == 'D'){ //if guess lands on a ship, change all of the ship's symbol to an 'x' to indicate a sink
            shipSymbol = opponent.defense.grid[randX][randY];

            for(i = 0; i < 5; i ++) {
                if(opponent.ships[i].getSymbol() == shipSymbol)
                    break;
            }
            opponent.ships[i].setSunk(true); //ship is sunk
            opponent.setSunkCount(opponent.getSunkCount() + 1); //opponent's number of ships sunk increases by 1

            if(opponent.ships[i].getOrient() == "H") {
                for(int j = 0; j < opponent.ships[i].getLength(); j ++) {
                    opponent.defense.grid[opponent.ships[i].getXCoor()][opponent.ships[i].getYCoor() + j] = 'x';
                    attack.grid[opponent.ships[i].getXCoor()][opponent.ships[i].getYCoor() + j] = 'x';
                }
            }else{
                for(int j = 0; j < opponent.ships[i].getLength(); j ++) {
                    opponent.defense.grid[opponent.ships[i].getXCoor() + j][opponent.ships[i].getYCoor()] = 'x';
                    attack.grid[opponent.ships[i].getXCoor() + j][opponent.ships[i].getYCoor()] = 'x';
                }
            }
            cout << "Hit! Computer has sunk your " << opponent.ships[i].getType() << "!" << endl;
            return true;
        }
    }
}

bool Player::guessManually(Player &opponent) {
    string userGuess;
    cout << "Please enter a coordinate (A1-J10) for your guess:" << endl;
    cin >> userGuess;
    int* userGuessInts = coordToInt(userGuess.c_str());
    char shipSymbol;
    int i;

    while(true) {
        if (opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] ==
            '~') { //if guess lands over water, return false
            attack.grid[userGuessInts[1]][userGuessInts[0]] = 'o';
            cout << "Miss!" << endl;
            return false;
        } else if (attack.grid[userGuessInts[1]][userGuessInts[0]] == 'x' ||
                   attack.grid[userGuessInts[1]][userGuessInts[0]] ==
                   'o') { //if guess lands on a previous guess, guess again
            continue;
        } else if (opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] == 'C' ||
                   opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] == 'B' ||
                   opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] == 'Z' ||
                   opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] == 'S' ||
                   opponent.defense.grid[userGuessInts[1]][userGuessInts[0]] ==
                   'D') { //if guess lands on a ship, change all of the ship's symbol to an 'x' to indicate a sink
            shipSymbol = opponent.defense.grid[userGuessInts[1]][userGuessInts[0]];

            for (i = 0; i < 5; i++) {
                if (opponent.ships[i].getSymbol() == shipSymbol)
                    break;
            }
            opponent.ships[i].setSunk(true); //ship is sunk
            opponent.setSunkCount(opponent.getSunkCount() + 1); //opponent's number of ships sunk increases by 1

            if (opponent.ships[i].getOrient() == "H") {
                for (int j = 0; j < opponent.ships[i].getLength(); j++) {
                    opponent.defense.grid[opponent.ships[i].getXCoor()][opponent.ships[i].getYCoor() + j] = 'x';
                    attack.grid[opponent.ships[i].getXCoor()][opponent.ships[i].getYCoor() + j] = 'x';
                }
            } else {
                for (int j = 0; j < opponent.ships[i].getLength(); j++) {
                    opponent.defense.grid[opponent.ships[i].getXCoor() + j][opponent.ships[i].getYCoor()] = 'x';
                    attack.grid[opponent.ships[i].getXCoor() + j][opponent.ships[i].getYCoor()] = 'x';
                }
            }
            cout << "Hit! You have sunk the computer's " << opponent.ships[i].getType() << "!" << endl;
            return true;
        }
        return false;
    }

}

int* Player::coordToInt(const char* toConvert) {
    if(toConvert[0] >= 65 && toConvert[0] < 74)
        tempCoords[0] = (toConvert[0]-4)%10;
    else if(toConvert[0] == 74)
        tempCoords[0] = 10;
    else{
        try{
            throw InvalidCoordException();
        }catch (InvalidCoordException a){
            cout << "Invalid Coordinate Exception. Pick a letter between A and J (inclusive).";
            exit(1);
        }
    }

    if(strlen(toConvert) == 2) {
        if(toConvert[1] >= 49 && toConvert[1] <= 57)
            tempCoords[1] = (toConvert[1]-8)%10;
    }else if(strlen(toConvert) == 3) {
        if(toConvert[1] >= 49 && toConvert[1] <= 57 && toConvert[2] == 48)
            tempCoords[1] = 9;
        else
            try{
                throw InvalidCoordException();
            }catch (InvalidCoordException a){
                cout << "Invalid Coordinate Exception. Pick a number between 1 and 10 (inclusive).";
                exit(1);
            }
    }
    return tempCoords;
}

int Player::getSunkCount() const {
    return sunkCount;
}

void Player::setSunkCount(int sunkCount) {
    Player::sunkCount = sunkCount;
}
