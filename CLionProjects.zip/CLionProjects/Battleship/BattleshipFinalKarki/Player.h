//
// Created by ryanr on 11/5/2019.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include <cstring>
#include "Grid.h"
class Player{
private:
    bool type; //0 = human, 1 = AI
    int sunkCount;
public:
    Grid attack; //grid with guesses
    Grid defense; //grid with ships
    Ship ships[5]; //list of player ships
    int tempCoords[2]; //array for coordToInt to work
    Player():type(1), sunkCount(0) {}
    void placeShipsFromFile(); //places ships on grid from file reading
    void placeShipsRandomly(); //places ships on grid randomly
    void printShips(); //lists all ships belonging to this player
    bool guessRandomly(Player &opponent); //generates random coordinate. returns true on hit, false on miss
    bool guessManually(Player &opponent); //coordinate given by user input. returns true on hit, false on miss
    int* coordToInt(const char* toConvert); //Converts a Battleship coordinate to integers, i.e. B7 to [2,7]
    int getSunkCount() const; //returns the number of this player's sunken ships

    void setSunkCount(int sunkCount);
};
#endif //BATTLESHIP_PLAYER_H
