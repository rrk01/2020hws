//
// Created by ryanr on 11/5/2019.
//

#include "Ship.h"

const string &Ship::getType() const {
    return type;
}

void Ship::setType(const string &type) {
    Ship::type = type;
}

const string &Ship::getOrient() const {
    return orient;
}

void Ship::setOrient(const string &orient) {
    Ship::orient = orient;
}

int Ship::getXCoor() const {
    return xCoor;
}

void Ship::setXCoor(int xCoor) {
    Ship::xCoor = xCoor;
}

int Ship::getYCoor() const {
    return yCoor;
}

void Ship::setYCoor(int yCoor) {
    Ship::yCoor = yCoor;
}

int Ship::getLength() const {
    return length;
}

void Ship::setLength(int length) {
    Ship::length = length;
}

char Ship::getSymbol() const {
    return symbol;
}

void Ship::setSymbol(char symbol) {
    Ship::symbol = symbol;
}

bool Ship::isPlaced() const {
    return placed;
}

void Ship::setPlaced(bool placed) {
    Ship::placed = placed;
}

bool Ship::isSunk() const {
    return sunk;
}

void Ship::setSunk(bool sunk) {
    Ship::sunk = sunk;
}
