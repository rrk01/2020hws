//
// Created by ryanr on 11/5/2019.
//

#ifndef BATTLESHIP_SHIP_H
#define BATTLESHIP_SHIP_H

#include <iostream>
#include <string>
#include "Exceptions.h"
using namespace std;
class Ship{
private:
    string type; //Carrier, Battleship, Cruiser, Submarine, Destroyer
    string orient; //Horizontal (H) or Vertical (V)
    int xCoor; //coordinates of starting point of ship
    int yCoor; //yCoor is actually the x coordinate of the ship and vice versa...
    int length; //2-5. Carrier = 5, Battleship = 4, Cruiser & Submarine = 3, Destroyer = 2
    char symbol; //Carrier = C, Battleship = B, Cruiser = Z, Submarine = S, Destroyer = D
    bool placed; //for random generation. becomes true if ship is placed successfully
    bool sunk; //false by default, becomes true when the ship is hit
public:
    Ship() {
        type = "N/A";
        orient = "X";
        xCoor = -1;
        yCoor = -1;
        length = 0;
        symbol = 0;
        placed = false;
        sunk = false;
    }

    const string &getType() const;

    void setType(const string &type);

    const string &getOrient() const;

    void setOrient(const string &orient);

    int getXCoor() const;

    void setXCoor(int xCoor);

    int getYCoor() const;

    void setYCoor(int yCoor);

    int getLength() const;

    void setLength(int length);

    char getSymbol() const;

    void setSymbol(char symbol);

    bool isPlaced() const;

    void setPlaced(bool placed);

    bool isSunk() const;

    void setSunk(bool sunk);
};
#endif //BATTLESHIP_SHIP_H
