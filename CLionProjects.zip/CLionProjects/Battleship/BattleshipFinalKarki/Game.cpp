//
// Created by ryanr on 11/5/2019.
//

#include "Game.h"

void Game::readShipsFromFile(Ship playerShips[], string fileName) { //CSV reader
    string line;
    string tempType, tempPos, tempOrient;
    const char* coords;
    char tempX, tempY;
    int* intCoords;
    int counter = 0;

    ifstream fin;
    fin.open(fileName);
    if(fin.fail()){
        cout << "Input file opening failed.\n";
        exit(1);
    }

    while(getline(fin, line) && counter < 5) {
        try{
            stringstream s(line);

            getline(s, tempType, ',');
            getline(s, tempPos, ',');
            getline(s, tempOrient, ',');

            coords = tempPos.c_str();
            intCoords = player1.coordToInt(coords);
            tempX = intCoords[0];
            tempY = intCoords[1];

            if(tempX < 1 || tempX > 10 || tempY < 1 || tempY > 10) //end program if invaalid coords, i.e. K0, Z27
                throw InvalidCoordException();

            playerShips[counter].setType(tempType);
            playerShips[counter].setXCoor(tempY);
            playerShips[counter].setYCoor(tempX);
            playerShips[counter].setOrient(tempOrient);

            //checks name of the ships and gives it a board symbol and length. throws an exception if not a valid ship name
            if(playerShips[counter].getType() == "Carrier") {
                playerShips[counter].setLength(5);
                playerShips[counter].setSymbol('C');
            }else if(playerShips[counter].getType() == "Battleship"){
                playerShips[counter].setLength(4);
                playerShips[counter].setSymbol('B');
            }else if(playerShips[counter].getType() == "Cruiser") {
                playerShips[counter].setLength(3);
                playerShips[counter].setSymbol('Z');
            }else if(playerShips[counter].getType() == "Submarine") {
                playerShips[counter].setLength(3);
                playerShips[counter].setSymbol('S');
            }else if(playerShips[counter].getType() == "Destroyer") {
                playerShips[counter].setLength(2);
                playerShips[counter].setSymbol('D');
            }else
                throw InvalidShipNameException();
        }catch(InvalidShipNameException a) {
            cout << "Invalid Ship Name";
            exit(1);
        }
        catch (InvalidCoordException a) {
            cout << "Invalid Coordinates";
            exit(1);
        }

        counter ++;
    }

    fin.close();

    cout << "File " << fileName << " successfully read!" << endl;
}