//
// Created by ryanr on 9/18/2019.
//

#include "Grid.h"

void Grid::manualFill() { //manually fill 2d vector
    int userSize;
    bool userIn;
    cout << "Enter grid size n (grid will be n*n square):" << endl;
    cin >> userSize;
    setSize(userSize);
    for(int i = 0; i < userSize; i ++) {
        for(int j = 0; j < userSize; j ++){
            cout << "Enter boolean value for (" << i << "," << j << ")" << endl;
            cin >> userIn;
            g[i].push_back(userIn);
        }
    }
}

void Grid::randomFill() { //fills with AT LEAST 1/3 1's
    int userSize;
    int count = 0;
    int random;
    cout << "Enter grid size n (grid will be n*n square):" << endl;
    cin >> userSize;
    setSize(userSize);
    int area = userSize*userSize; //area of a square
    for(int i = 0; i < userSize; i ++) { //loops to fill a 2d vector
        g.push_back(vector<bool>());
        for(int j = 0; j < userSize; j ++){
            random = rand()%3;
            if(area-(area-count) <= area/3) { //statement to determine to fill with AT LEAST 1/3 1's
                if(random == 0) {
                    g[i].push_back(0);
                    count ++;
                }else{
                    g[i].push_back(1);
                }
            }else{
                g[i].push_back(0);
            }
        }
    }
}

void Grid::print() { //output a 2d vector
    for(int i = 0; i < g.size(); i ++) {
        for (int j = 0; j < g[i].size(); j++) {
            cout << g[i][j] << " ";
        }
        cout << endl;
    }
}

Grid Grid::operation(Grid input) {
    Grid newGrid;
    int inputGetSize = input.getSize();
    int thisGetSize = getSize();

    if(inputGetSize != thisGetSize) {
        cout << "Input must be the same size grid!" << endl;
        return newGrid;
    }
    for(int i = 0; i < size; i ++) { //checks if both grids' coordinates is a '1'
        newGrid.g.push_back(vector<bool>());
        for(int j = 0; j < size; j ++){
            if(g[i][j] == 1 && input.g[i][j] == 1) {
                newGrid.g[i].push_back(1);
            }else{
                newGrid.g[i].push_back(0);
            }
        }
    }
    return newGrid;
}

int Grid::getSize() const {
    return size;
}

void Grid::setSize(int s) {
    Grid::size = s;
}
