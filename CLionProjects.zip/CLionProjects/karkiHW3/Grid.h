//
// Created by ryanr on 9/18/2019.
//

#ifndef KARKIHW3_GRID_H
#define KARKIHW3_GRID_H

#include <iostream>
#include <vector>
using namespace std;

class Grid {
private:
    int size;
public:
    vector<vector<bool>> g; //can only be 0 or 1

    Grid(){} //default constructor

    int getSize() const;
    void setSize(int size);
    void manualFill(); //manually fill 2d vector
    void randomFill(); //fills with AT LEAST 1/3 1's
    void print(); //output 2d vector
    Grid operation(Grid input); //returns a Grid with intersecting 1's
};

#endif //KARKIHW3_GRID_H
