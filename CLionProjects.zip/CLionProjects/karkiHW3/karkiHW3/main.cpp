#include "Grid.h"

int main() {
    int userSeed;
    cout << "Pick random seed:" << endl;
    cin >> userSeed;
    srand(userSeed);
    Grid grid1;
    Grid grid2;
    Grid grid3;
    grid1.randomFill();
    grid1.print();
    grid2.randomFill();
    grid2.print();
    grid3 = grid1.operation(grid2);
    cout << endl;
    grid3.print();
    return 0;
}