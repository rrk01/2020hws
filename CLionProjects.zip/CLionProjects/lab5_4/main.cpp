#include <iostream>

#include <fstream>

#include <vector>

using namespace std;

int main() {
    cout << 6;
}