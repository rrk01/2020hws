//
// Created by ryanr on 7/26/2019.
//

#ifndef LAB10_FUNCTIONS_H
#define LAB10_FUNCTIONS_H
int* allocateArray(int arraySize);
int* increaseArray(int* array, int &currentSize, int IncreaseBy);
void listArray(int array[], int size);
#endif //LAB10_FUNCTIONS_H
