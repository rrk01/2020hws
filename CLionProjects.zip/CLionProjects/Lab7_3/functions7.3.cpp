//
// Created by ryanr on 7/25/2019.
//

#include <iostream>
#include "functions7.3.h"
using namespace std;

int largestNumber(int num1, int num2, int num3) {
    int a;
    if(num1 > num2 && num1 > num3)
        a = num1;
    else if(num2 > num1 && num2 > num3)
        a = num2;
    else
        a = num3;
    cout << "largest: " << a << endl;
    return a;
}
int smallestNumber(int num1, int num2, int num3) {
    int a;
    if(num1 < num2 && num1 < num3)
        a = num1;
    else if(num2 < num1 && num2 < num3)
        a = num2;
    else
        a = num3;
    cout << "smallest: " << a << endl;
    return a;
}