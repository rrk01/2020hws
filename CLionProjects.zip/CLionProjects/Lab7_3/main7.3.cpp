#include <iostream>
#include "functions7.3.h"
using namespace std;

int main() {
    int z,y,x;
    cin >> z >> y >> x;
    largestNumber(z,y,x);
    smallestNumber(z,y,x);
    return 0;
}