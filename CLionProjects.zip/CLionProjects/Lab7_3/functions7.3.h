//
// Created by ryanr on 7/25/2019.
//

#ifndef LAB7_3_FUNCTIONS7_3_H
#define LAB7_3_FUNCTIONS7_3_H
int largestNumber(int num1, int num2, int num3);
int smallestNumber(int num1, int num2, int num3);
#endif //LAB7_3_FUNCTIONS7_3_H
