#include <iostream>
#include <vector>
using namespace std;

int main() {
    int numOfTestScores;
    cin >> numOfTestScores;
    vector<int> testScores;
    for(int i = 0; i < numOfTestScores; i ++) {
        cin >> testScores.at(i);
    }
    return 0;
}