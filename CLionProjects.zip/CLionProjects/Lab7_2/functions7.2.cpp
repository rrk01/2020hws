//
// Created by ryanr on 7/25/2019.
//
#include <iostream>
#include "functions7.2.h"
using namespace std;

bool isLeapYear(int userYear) {
    bool x;
    if(userYear % 4 != 0) {
        x = false;
    }else if((userYear % 100 == 0) && (userYear % 400 != 0)) {
        x = false;
    }else{
        x = true;
    }
    if(x) {
        cout << userYear << " is a leap year." << endl;
    }else{
        cout << userYear << " is not a leap year." << endl;
    }
    return x;
}