#include <iostream>
#include "functions7.2.h"
using namespace std;

int main() {
    int userIn;
    cin >> userIn;
    isLeapYear(userIn);
    return 0;
}