//
// Created by ryanr on 7/25/2019.
//

#ifndef LAB7_2_FUNCTIONS7_2_H
#define LAB7_2_FUNCTIONS7_2_H

bool isLeapYear(int userYear);

#endif //LAB7_2_FUNCTIONS7_2_H