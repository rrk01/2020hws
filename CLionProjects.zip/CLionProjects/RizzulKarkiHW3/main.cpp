#include <iostream>
#include <fstream>
#include "Set.h"
#include "ArrayBag.h"
#include "BagInterface.h"

using namespace std;

int main() {
    ifstream infile("setInput.txt");

    return 0;
}