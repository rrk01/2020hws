//
// Created by ryanr on 9/27/2019.
//

#include "Set.h"
#include "ArrayBag.h"
#include "BagInterface.h"

using namespace std;

template <class ItemType>
ArrayBag<ItemType> Set<ItemType>::onion(const ArrayBag<ItemType> &bag2) {
    ArrayBag<ItemType> newArrayBag;
    vector<ItemType> vec1 = a.toVector();
    vector<ItemType> vec2 = bag2.toVector();

    for(int i = 0; i < a.itemCount; i ++) {
        newArrayBag.add(vec1[i]);
    }
    for(int i = 0; i < bag2.itemCount; i ++) {
        newArrayBag.add(vec2[i]);
    }

    return newArrayBag;

}

template <class ItemType>
ArrayBag<ItemType> Set<ItemType>::intersection(const ArrayBag<ItemType> &bag2) {
    ArrayBag<ItemType> newArrayBag;
    vector<ItemType> vec1 = a.toVector();
    vector<ItemType> vec2 = bag2.toVector();

    int bagSize;

    if(a.itemCount < bag2.itemCount) {
        bagSize = bag2.itemCount;
        for(int i = 0; i < bagSize; i ++) {
            if(a.contains(bag2[i]))
                newArrayBag.add(bag2[i]);
        }
    }else{
        bagSize = a.itemCount;
        for(int i = 0; i < bagSize; i ++) {
            if (bag2.contains(a[i]))
                newArrayBag.add(a[i]);
        }
    }

}