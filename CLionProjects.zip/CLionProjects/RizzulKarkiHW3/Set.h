//
// Created by ryanr on 9/27/2019.
//

#ifndef RIZZULKARKIHW3_SET_H
#define RIZZULKARKIHW3_SET_H

#include "ArrayBag.h"
#include "BagInterface.h"

template <class ItemType>
class Set : public ArrayBag<ItemType> {
private:
    ArrayBag<ItemType> a;
public:
    const ArrayBag<ItemType> &getA() const {
        return a;
    }

    void setA(const ArrayBag<ItemType> &a) {
        Set::a = a;
    }

    ArrayBag<ItemType> onion(const ArrayBag<ItemType> &bag2);
    ArrayBag<ItemType> intersection(const ArrayBag<ItemType> &bag2);

};

#endif //RIZZULKARKIHW3_SET_H
