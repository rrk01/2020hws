#include <iostream>
#include <queue>
#include <vector>
#include <fstream>
#include <stdio.h>
#include "Car.h"

using namespace std;

int main() {
    queue<Car> carWash; //data structure for car wash
    vector<Car> totalCars; //to take stats easier


    //USER INPUT FOR SIMULATION TIME
    cout << "Please enter simulation end time (minutes):" << endl;
    int SIMULATION_END_TIME; //number of minutes to pass since 8:00 am (wash open)
    cin >> SIMULATION_END_TIME;
    //

    //STAT VARIABLES
    Time washHours(SIMULATION_END_TIME); //struct for reading the time
    int numCarsBeforeClose = 0; //how many cars were washed before wash close
    int totalWaitTime = 0; //wait time for all cars combined
    float averageWaitTime = 0; //average wait time of all the cars
    float percentTimeWashInUse; //percentage of the total time the car wash was in use
    //

    //READ FROM FILE
    ifstream myfile("arrival_time.txt");
    int carInTime; //int to be extracted from file (arrival time)
    int counter = 1; //counter for car number
    //

    //PRINT OPENING AND CLOSING TIMES
    cout << "Opening Time: " << "8:00 AM (0 minutes)" << endl;
    if(washHours.minute < 10)
        cout << "Closing Time: " << washHours.hour << ":0" << washHours.minute;
    else
        cout << "Closing Time: " << washHours.hour << ":" << washHours.minute;
    if(washHours.ampm == 0)
        cout << " AM";
    else
        cout << " PM";
    cout << " (" << SIMULATION_END_TIME << " minutes)" << endl << endl;
    cout << "START OF SIMULATION" << endl << endl;
    //

    printf("Car Number \tArrival Time \tWash Start Time \t Departure Time \tWait Time \t Total Time\n");
    cout << "-------------------------------------------------------------------------------------------------------------" << endl;

    //CAR WASH SIMULATION
    if (myfile.is_open()){
        while (myfile >> carInTime) {
            if(counter == 1 || carInTime >= carWash.front().getDepartureTime()) { //if first car to arrive OR previous car has already left
                carWash.push(Car(counter, carInTime, carInTime)); //new car's wash start time is the same as its arrival time
                totalCars.emplace_back(counter, carInTime, carInTime);
            }else{
                carWash.push(Car(counter, carInTime, carWash.front().getDepartureTime())); //new car's wash start time is the same as the previous car's departure time
                totalCars.emplace_back(counter, carInTime, carWash.front().getDepartureTime());
            }
            counter++; //increment counter for car number
            if(counter >= 3) {
                if(carWash.front().getArrivalTime() > SIMULATION_END_TIME) { //if car arrives after wash is closed
                    printf("%d\t\t%d Car arrived after closing time and was not served.\n",
                           carWash.front().getNumber(), carWash.front().getArrivalTime());
                    numCarsBeforeClose++;

                }else{
                    printf("%d\t\t%d\t\t%d\t\t\t %d\t\t\t%d\t\t %d\t\t\n", carWash.front().getNumber(), carWash.front().getArrivalTime(),
                           carWash.front().getWashStartTime(), carWash.front().getDepartureTime(),
                           carWash.front().getWaitTime(), carWash.front().getTotalTime());
                }
                carWash.pop();
            }

        }
        myfile.close();
    }
    if(carWash.front().getArrivalTime() > SIMULATION_END_TIME) { //copy paste to read last item in queue. without this it doesn't read the last item in queue
        printf("%d\t\t%d\t\tCar arrived after closing time and was not served.\n",
               carWash.front().getNumber(), carWash.front().getArrivalTime());
        numCarsBeforeClose++;

    }else{
        printf("%d\t\t%d\t\t%d\t\t\t %d\t\t\t%d\t\t %d\t\t\n", carWash.front().getNumber(), carWash.front().getArrivalTime(),
               carWash.front().getWashStartTime(), carWash.front().getDepartureTime(),
               carWash.front().getWaitTime(), carWash.front().getTotalTime());
    }
    //

    cout << endl << "END OF SIMULATION" << endl << endl;

    //CALCULATE STATS
    for(int i = 0; i < totalCars.size(); i ++){ //calculate total wait time
        totalWaitTime += totalCars[i].getWaitTime();
        averageWaitTime += totalCars[i].getWaitTime();
    }
    numCarsBeforeClose = counter - numCarsBeforeClose - 1; //how many cars are washed
    averageWaitTime /= numCarsBeforeClose; //calculate average wait time
    int minutes = averageWaitTime; //average wait in minutes
    int seconds = (averageWaitTime-minutes)*60; //average wait in seconds
    //

    //PRINT STATS
    cout << "Statistics:" << endl;
    cout << "Cars washed:\t\t\t\t" << numCarsBeforeClose << " cars" << endl;
    cout << "Total Wait Time:\t\t\t" << totalWaitTime << " minutes" << endl;
    cout << "Average Wait Time:\t\t\t" << minutes << " minute " << seconds << " second" << endl;
    cout << "Total Car Wash Use Time:\t\t" << numCarsBeforeClose*3 << " minutes" << endl;
    percentTimeWashInUse = (static_cast<float>(numCarsBeforeClose*3)/SIMULATION_END_TIME)*100;
    cout << "Percent of Time Car Wash in Use:\t\t" << percentTimeWashInUse << "%" << endl;
    //

    //END OF PROGRAM

    return 0;
}