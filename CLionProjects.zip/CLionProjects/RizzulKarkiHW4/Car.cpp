//
// Created by ryanr on 10/3/2019.
//
#include "Car.h"

int Car::getNumber() const {
    return number;
}

void Car::setNumber(int number) {
    Car::number = number;
}

int Car::getArrivalTime() const {
    return arrivalTime;
}

void Car::setArrivalTime(int arrivalTime) {
    Car::arrivalTime = arrivalTime;
}

int Car::getWashStartTime() const {
    return washStartTime;
}

void Car::setWashStartTime(int washStartTime) {
    Car::washStartTime = washStartTime;
}

Car::Car(int number, int arrivalTime, int washStartTime) : number(number), arrivalTime(arrivalTime),
                                                           washStartTime(washStartTime) {
    departureTime = washStartTime + 3;
    waitTime = washStartTime - arrivalTime;
    totalTime = departureTime - arrivalTime;
}

Car::~Car() {}

int Car::getWaitTime() const {
    return waitTime;
}

void Car::setWaitTime(int waitTime) {
    Car::waitTime = waitTime;
}

int Car::getTotalTime() const {
    return totalTime;
}

void Car::setTotalTime(int totalTime) {
    Car::totalTime = totalTime;
}

int Car::getDepartureTime() const {
    return departureTime;
}

void Car::setDepartureTime(int departureTime) {
    Car::departureTime = departureTime;
}