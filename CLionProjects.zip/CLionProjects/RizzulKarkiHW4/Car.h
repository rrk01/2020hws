//
// Created by ryanr on 10/3/2019.
//

#ifndef RIZZULKARKIHW4_CAR_H
#define RIZZULKARKIHW4_CAR_H

class Car {
private:
    int number;
    int arrivalTime;
    int washStartTime;
    int departureTime;
    int waitTime;
    int totalTime;
public:
    int getWaitTime() const;

    void setWaitTime(int waitTime);

    int getTotalTime() const;

    void setTotalTime(int totalTime);

public:
    Car():number(-1), arrivalTime(-1), washStartTime(-1), departureTime(-1), waitTime(-1), totalTime(-1) {}

    int getDepartureTime() const;

    void setDepartureTime(int departureTime);

    virtual ~Car();

    Car(int number, int arrivalTime, int washStartTime);

    int getNumber() const;

    void setNumber(int number);

    int getArrivalTime() const;

    void setArrivalTime(int arrivalTime);

    int getWashStartTime() const;

    void setWashStartTime(int washStartTime);

};

struct Time {
    int hour;
    int minute;
    bool ampm = 0; //0 = AM , 1 = PM
    Time(int x) {
        hour = (8 + x/60)%12;
        if(hour == 0)
            hour = 12;
        minute = x%60;
        if(x >= 240)
            ampm = 1;
    }
};

#endif //RIZZULKARKIHW4_CAR_H
