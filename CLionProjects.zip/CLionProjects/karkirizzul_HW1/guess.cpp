//
// Created by ryanr on 9/9/2019.
//

#include "guess.h"

Guess::Guess(){
    generateGameNums();
    for(int i = 0; i < 4; i ++) {
        cout << gameNums[i] << " " << endl;
    }
}

void Guess::generateGameNums() {
    for(int i = 0; i < 4; i ++) { //generate numbers 1-9
        gameNums[i] = rand()%8+1;
    }
}

void Guess::play() {
    int userGuess[4];
    int gameNumsTemp[4];
    for(int i = 0; i < 4; i ++) { //save
        gameNumsTemp[i] = gameNums[i];
    }
    string userString = "";
    int correctGuesses = -1;
    while(userString != "no" && userString != "No") { //while user does not enter 'no'
        correctGuesses = 0;
        for(int i = 0; i < 4; i ++) { //reload
            gameNums[i] = gameNumsTemp[i];
        }
        cout << "Enter your guesses for the 4 integers in the range from 1 to 9 that have been selected:" << endl;
        cin >> userGuess[0] >> userGuess[1] >> userGuess[2] >> userGuess[3];
        if ((userGuess[0] > 9 || userGuess[0] < 1) || (userGuess[1] > 9 || userGuess[1] < 1) || (userGuess[2] > 9 || userGuess[2] < 1) ||
            (userGuess[3] > 9 || userGuess[3] < 1)) { //checks if guesses are in bounds
            cout << "Make sure your guesses are between 1 and 9!" << endl;
            continue;
        }
        for(int i = 0; i < 4; i ++) { //compare elements of arrays
            for(int j = 0; j < 4; j ++) {
                if(userGuess[j] == gameNums[i]) {
                    correctGuesses ++;
                    userGuess[j] = -1;
                    gameNums[i] = -1;
                }
            }
        }
        if(correctGuesses < 4) {
            cout << correctGuesses << " of your guesses are correct. Guess again." << endl;
        }else{
            cout << "You are correct! Play again?" << endl;
            cin >> userString;
        }
    }

}