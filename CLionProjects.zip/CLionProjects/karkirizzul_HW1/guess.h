//
// Created by ryanr on 9/2/2019.
//

#ifndef KARKIRIZZUL_HW1_GUESS_H
#define KARKIRIZZUL_HW1_GUESS_H

#include <iostream>
#include <string>
using namespace std;

class Guess;

class Guess {
private:
    int gameNums[4];
public:
    Guess();
    void generateGameNums();
    void play();
};

#endif //KARKIRIZZUL_HW1_GUESS_H
