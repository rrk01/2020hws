#include <iostream>
#include <string>
#include "guess.h"
using namespace std;

int main() {
    srand(1);
    Guess game1;
    game1.play();
    return 0;
}