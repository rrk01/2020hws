Ryan Karki
107867709
status = works completely
Windows 10
