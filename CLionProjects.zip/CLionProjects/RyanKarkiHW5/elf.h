//
// Created by ryanr on 10/25/2019.
//

#ifndef RYANKARKIHW5_ELF_H
#define RYANKARKIHW5_ELF_H
using namespace std;

class elf: public Creature
{
public:
    elf();
    elf(const int& newStrenght, const int& newHit);
    string getSpecies();
    int getDamage();



};
#endif //RYANKARKIHW5_ELF_H
