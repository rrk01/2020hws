//
// Created by ryanr on 10/25/2019.
//

#ifndef RYANKARKIHW5_DEMON_H
#define RYANKARKIHW5_DEMON_H
using namespace std;

class demon: public Creature
{
public:
    demon();
    demon(const int& newStrenght, const int& newHit);
    string getSpecies();
    int getDamage();



};
#endif //RYANKARKIHW5_DEMON_H
