//
// Created by ryanr on 10/25/2019.
//

#ifndef RYANKARKIHW5_HUMAN_H
#define RYANKARKIHW5_HUMAN_H
#include <string>
#include "creature.h"
using namespace std;

class human: public Creature
{
public:
    human();
    human(const int& newStrenght, const int& newHit);
    int getDamage();
    string getSpecies();




};
#endif //RYANKARKIHW5_HUMAN_H
