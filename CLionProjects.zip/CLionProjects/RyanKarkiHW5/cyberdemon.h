//
// Created by ryanr on 10/25/2019.
//

#ifndef RYANKARKIHW5_CYBERDEMON_H
#define RYANKARKIHW5_CYBERDEMON_H
using namespace std;

class cyberdemon: public demon
{
public:
    cyberdemon();
    cyberdemon(const int& newStrenght, const int& newHit);
    string getSpecies();
    int getDamage();



};
#endif //RYANKARKIHW5_CYBERDEMON_H
