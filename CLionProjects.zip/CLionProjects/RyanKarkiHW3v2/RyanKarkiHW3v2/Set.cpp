//
// Created by ryanr on 10/4/2019.
//

#include "Set.h"

int Set::contains(int numberToFind) {
    int counter;
    if(set.empty())
        return 0;
    for(int i = 0; i < set.size(); i ++) {
        if(set[i] == numberToFind)
            counter ++;
    }
    return counter;
}

const vector<int> &Set::getSet() const {
    return set;
}

vector<int> Set::onion(Set &anotherSet) {
    vector<int> tempUnion;
    for(int i = 0; i < set.size(); i ++) {
        tempUnion.push_back(set[i]);
    }
    for(int i = 0; i < anotherSet.set.size(); i ++) {
        tempUnion.push_back(anotherSet.set[i]);
    }
    return tempUnion;
}

vector<int> Set::intersection(Set &anotherSet) {
    vector<int> tempIntersection;
    if (anotherSet.set.size() >= set.size()) {
        for(int i = 0; i < set.size(); i ++) {
            if(anotherSet.contains(set[i]) == 0) {
                continue;
            }else if (anotherSet.contains(set[i]) <= contains(set[i])) {
                tempIntersection.push_back(set[i]);
            }
        }
    }else{
        for(int i = 0; i < anotherSet.set.size(); i ++) {
            if(contains(anotherSet.set[i]) == 0) {
                continue;
            }else if (contains(set[i] <= anotherSet.contains(anotherSet.set[i]))) {
                tempIntersection.push_back(anotherSet.set[i]);
            }
        }
    }
    return tempIntersection;
}