//
// Created by ryanr on 10/4/2019.
//

#ifndef RYANKARKIHW3V2_SET_H
#define RYANKARKIHW3V2_SET_H

#include <vector>

using namespace std;

class Set{
public:
    vector<int> set;

    Set() {}

    int contains(int numberToFind);

    const vector<int> &getSet() const;

    vector<int> onion(Set &anotherSet);

    vector<int> intersection(Set &anotherSet);
};
#endif //RYANKARKIHW3V2_SET_H
