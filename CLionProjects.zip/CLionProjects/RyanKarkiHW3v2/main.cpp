#include <iostream>
#include "Set.h"

int main() {
    Set a;
    Set b;
    for(int i = 1; i <= 5; i ++) {
        a.set.push_back(i);
    }
    for(int i = 1; i <= 5; i ++) {
        b.set.push_back(i/2);
    }
    cout << endl << "Union Set:" << endl;
    for(int i = 0; i < a.onion(b).size(); i ++) {
        cout << a.onion(b)[i] << " ";
    }
    cout << endl << "Intersection Set:" << endl;
    for(int i = 0; i < a.intersection(b).size(); i ++) {
        cout << a.intersection(b)[i] << " ";
    }
    return 0;
}