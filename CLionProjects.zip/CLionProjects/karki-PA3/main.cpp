#include <iostream>
#include <vector>
#include <fstream>
#include "Function.h"
#include "Dealer.h"
using namespace std;


int main() {
    ifstream infile;  // reading
    ofstream outfile; // writing

    vector<Dealer> vecDealer;
    string userMenuSelection = "null";
    while(userMenuSelection != "quit") {
        printMenu();
        cin >> userMenuSelection;
        if (userMenuSelection == "A" || userMenuSelection == "a" || userMenuSelection == "1") { //if user selects A
            readFile(infile, vecDealer); //1. Read Dealers and Cars from file
        } else if (userMenuSelection == "B" || userMenuSelection == "b" ||
                   userMenuSelection == "2") { //if user selects B
            displayDealers(vecDealer);//2. Display Dealers
        } else if (userMenuSelection == "C" || userMenuSelection == "c" ||
                   userMenuSelection == "3") { //if user selects C
            displayCarOfDealer(vecDealer);
        } else if (userMenuSelection == "D" || userMenuSelection == "d" ||
                   userMenuSelection == "4") {//if user selects D
            addCar(vecDealer);
        }else if(userMenuSelection == "E" || userMenuSelection == "e" ||
                 userMenuSelection == "5") {
            modifyCar(vecDealer);
        } else if (userMenuSelection == "F" || userMenuSelection == "f" ||
                   userMenuSelection == "6") {//if user selects F
            sortCarDealer(vecDealer);
        } else if (userMenuSelection == "G" || userMenuSelection == "g" || userMenuSelection == "7") {//if user selects G
            writeFile(outfile, vecDealer);
        } else if (userMenuSelection == "H" || userMenuSelection == "h" || userMenuSelection == "8") {
            break;
        }

    }

    cout << "Goodbye." << endl;


// develope the menu and call functions developed in function.h/function.cpp





//        3.	Choose a Dealer Number, Display Cars
//        4.	Choose a Dealer Number, Add Car
//        5.	Choose a Dealer Number, List Cars and Modify a Car (EXTRA CREDIT)
//        6.	Choose a Dealer, Sort cars by VIN (EXTRA CREDIT)
//        7.	Write Dealers and Cars to file
//        8.	Exit


    return 0;
}