//
// Created by Iris Linck on 4/24/19.
//

#ifndef PA3SKELETON_FUNCTION_H
#define PA3SKELETON_FUNCTION_H

#include <iostream>
#include <vector>
#include "Dealer.h"
using namespace std;

//prototypes

void printMenu();

void readFile (ifstream &, vector<Dealer> &  );

void displayDealers(vector<Dealer> &);

void displayCarOfDealer(vector<Dealer> &);

void modifyCar (vector<Dealer> &);

void addCar (vector<Dealer> &);

void sortCarDealer(vector <Dealer> &);


void writeFile(ofstream &, vector<Dealer> &  );

void bubblesortCar(Car * , int size);

int linearSearchDealer(vector <Dealer> &, int ); // dealer vector and search value

int linearSearchCar(Car *, string, int ); // car pointer, search value vin  and size

#endif //PA3SKELETON_FUNCTION_H
