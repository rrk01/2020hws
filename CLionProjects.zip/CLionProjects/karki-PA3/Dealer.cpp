//
// Created by Iris Linck on 4/24/19.
//

#include "Dealer.h"

// here develop all the public methods from Dealer and Car classes
// Do not forget to use the pointer this-> when you refer a private member of a class.
// develop all the gets and sets and other constructors for Dealer and Car here

Car::Car() {  // default construction
    this->vin="";
    this->make = "";
    this->model = "";
    this->price = 0.0;
    this->year = 0;
}

Dealer::Dealer() {  // default constructor
    this->dealerNumber =0;
    this->dealerName = "";
    this->carArrayptr = nullptr;
    this->numberOfCars = 0;
}

const string &Car::getVin() const {
    return vin;
}

void Car::setVin(const string &vin) {
    Car::vin = vin;
}

const string &Car::getMake() const {
    return make;
}

void Car::setMake(const string &make) {
    Car::make = make;
}

const string &Car::getModel() const {
    return model;
}

void Car::setModel(const string &model) {
    Car::model = model;
}

int Car::getYear() const {
    return year;
}

void Car::setYear(int year) {
    Car::year = year;
}

double Car::getPrice() const {
    return price;
}

void Car::setPrice(double price) {
    Car::price = price;
}

int Dealer::getDealerNumber() const {
    return dealerNumber;
}

void Dealer::setDealerNumber(int dealerNumber) {
    Dealer::dealerNumber = dealerNumber;
}

const string &Dealer::getDealerName() const {
    return dealerName;
}

void Dealer::setDealerName(const string &dealerName) {
    Dealer::dealerName = dealerName;
}

int Dealer::getNumberOfCars() const {
    return numberOfCars;
}

void Dealer::setNumberOfCars(int numberOfCars) {
    Dealer::numberOfCars = numberOfCars;
}

ostream& operator<<(ostream &out, Dealer &d) { //overloaded cout<< for dealers.
    out << "Dealer Name:" << "\t" << d.getDealerName() << "\t"
        << "Number:" << "\t" << d.getDealerNumber() << endl;
    return out;
}

ostream& operator<<(ostream &out, Car &c) { //overloaded cout<< for cars.
    out << "Make:" << "\t" << c.getMake() << endl
        << "Model:" << "\t" << c.getModel() << endl
        << "Price:" << "\t" << c.getPrice() << endl
        << "VIN:" << "\t" << c.getVin() << endl
        << "Year:" << "\t" << c.getYear() << endl;
    return out;
}