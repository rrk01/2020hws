//
// Created by Iris Linck on 4/24/19.
//

#include "Function.h"
#include <fstream>
#include <iostream>
#include <vector>
#include "Dealer.h"
using namespace std;


// here you have to develop all the body for the function prototypes decared in Function.h

void printMenu() {
    cout << "Pick an option:" << endl;
    cout << "1. Read from a properly formatted file 'in.txt'" << endl;
    cout << "2. Display dealers" << endl;
    cout << "3. Choose a dealer number, display cars" << endl;
    cout << "4. Choose a dealer number, add car" << endl;
    cout << "5. Choose a Dealer Number, List Cars and Modify a Car" << endl;
    cout << "6. Choose a Dealer, Sort cars by VIN" << endl;
    cout << "7. Write Dealers and Cars to file" << endl;
    cout << "Type 'quit' to exit the program." << endl << endl;
}


void readFile (ifstream & infile, vector<Dealer> &vecDealer  ){

    infile.open("in.txt");
    int dealerNumber, dealerCar;
    string dealerName;

    string carVin, carMake, carModel;
    int carYear;
    double carPrice;

    Dealer d;

    while (getline (infile,dealerName)){
        infile >> dealerNumber;
        infile.ignore();
        infile >> dealerCar;
        infile.ignore();

        d.setDealerName(dealerName);
        d.setDealerNumber(dealerNumber);
        d.setNumberOfCars(dealerCar);

        int size = dealerCar;
        d.carArrayptr = new Car [size];

        for (int i=0; i < size; i++){
            getline (infile,carVin);
            getline(infile, carMake);
            getline(infile, carModel);
            infile >> carYear;
            infile.ignore();
            infile >> carPrice;
            infile.ignore();
            d.carArrayptr[i].setPrice(carPrice);
            d.carArrayptr[i].setYear(carYear);
            d.carArrayptr[i].setModel(carModel);
            d.carArrayptr[i].setMake(carMake);
            d.carArrayptr[i].setVin(carVin);

        }
        vecDealer.push_back(d);

    }

    // display vec dealer

    for (int indexdealer = 0; indexdealer < vecDealer.size(); indexdealer++){
        cout    << vecDealer[indexdealer].getDealerName()     << endl
                << vecDealer[indexdealer].getDealerNumber()   << endl
                << vecDealer[indexdealer].getNumberOfCars()   << endl;

        int sizeArrayCar = vecDealer[indexdealer].getNumberOfCars();

        // for each dealer[i] we have to make a loop to set the array of cars
        for (int indexcar =0; indexcar < sizeArrayCar; indexcar++){
            cout << vecDealer[indexdealer].carArrayptr[indexcar].getVin() << endl;
            cout << vecDealer[indexdealer].carArrayptr[indexcar].getMake() << endl;
            cout << vecDealer[indexdealer].carArrayptr[indexcar].getPrice() << endl;
            cout << vecDealer[indexdealer].carArrayptr[indexcar].getYear()  << endl;
            cout << vecDealer[indexdealer].carArrayptr[indexcar].getModel() << endl;
        }
    }
    cout << endl;
    cout << "File finished reading." << endl;
    infile.close();
}
void displayDealers(vector<Dealer> &vecDealer){

    for(int i = 0; i < vecDealer.size(); i ++) {
        cout << vecDealer[i]; //endl's built in to the overloaded operator! don't use endl.
    }

}

void displayCarOfDealer(vector<Dealer> &vecDealer){
    // choose a Dealer and display its cars
    displayDealers(vecDealer);
    int userDealerNum;
    cout << "Please select a dealer number to see their cars.";
    cin >> userDealerNum;
    int i;
    for(i = 0; i < vecDealer.size(); i ++) {
        if(vecDealer[i].getDealerNumber() == userDealerNum) { //linear search for Dealer number
            for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++) { //if found, print all Cars
                cout << vecDealer[i].carArrayptr[j];
            }
            break;
        }
    }
    if(i == vecDealer.size()) { //if not found, asks to try again
        cout << "Invalid dealer number. Please try again." << endl;
    }

}

void modifyCar (vector<Dealer> &vecDealer){
    // choose a Dealer and display all its cars
    // choose a car
    // modify car
    displayDealers(vecDealer);
    int userDealerNum;
    string userVinIn;
    cout << "Please select a dealer number to modify.";
    cin >> userDealerNum;
    int i;
    for(i = 0; i < vecDealer.size(); i ++) {
        if(vecDealer[i].getDealerNumber() == userDealerNum) { //linear search for Dealer number
            for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++) { //if found, print all Cars
                cout << vecDealer[i].carArrayptr[j];
            }
            cout << "Please select a car by VIN:" << endl;
            cin >> userVinIn;
            for(int j = 0; j < vecDealer[i].getNumberOfCars(); j ++) { //if found, search for Car VIN
                if (vecDealer[i].carArrayptr[j].getVin() == userVinIn) { //if found, commence operation
                    string userCarStr; //temp vars for new car info vv
                    int userCarYear;
                    double userCarPrice;
                    Car tempCar; //user-entered car

                    cout << "Please enter a VIN:" << endl; //User enters details for new car for the dealer vv
                    cin.ignore();
                    getline(cin, userCarStr);
                    tempCar.setVin(userCarStr);

                    cout << "Please enter a make:" << endl;
                    //cin.ignore();
                    getline(cin, userCarStr);
                    tempCar.setMake(userCarStr);

                    cout << "Please enter a model:" << endl;
                    //cin.ignore();
                    getline(cin, userCarStr);
                    tempCar.setModel(userCarStr);

                    cout << "Please enter a year:" << endl;
                    //cin.ignore();
                    cin >> userCarYear;
                    tempCar.setYear(userCarYear);

                    cout << "Please enter a price:" << endl;
                    //cin.ignore();
                    cin >> userCarPrice;
                    tempCar.setPrice(userCarPrice);

                    vecDealer[i].carArrayptr[j] = tempCar;

                    for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++) { //if found, print all Cars
                        cout << vecDealer[i].carArrayptr[j];
                    }
                }
            }
            break;
        }
    }
    if(i == vecDealer.size()) { //if not found, asks to try again
        cout << "Invalid dealer/VIN number. Please try again." << endl;
    }

}

void addCar (vector<Dealer> &vecDealer) {

    //display dealer info using operators located in Dealer.cpp and Dealer.h
    displayDealers(vecDealer);

    int dealerNum;
    int carYear;
    double carPrice;
    string carVin;
    string carMake;
    string carModel;
    bool foundDealer = false;
    Car newCar;

    //get response from user
    cout << "Please Enter The Dealer Number:";
    cin >> dealerNum;
    cin.ignore();

    //create a loop for cars
    for (int i = 0; i < vecDealer.size() && (!foundDealer); i++) {
        if (vecDealer[i].getDealerNumber() == dealerNum) {
            foundDealer = true;

            //user input of VINm make, model, year, and price
            cout << "Please Enter The Car VIN: ";
            getline(cin, carVin);

            cout << "Please Enter The Car Make: ";
            getline(cin, carMake);

            cout << "Please Enter The Car Model: ";
            getline(cin, carModel);


            cout << "Please Enter The Car Year: ";
            cin >> carYear;

            cout << "Please Enter The Car Price: ";
            cin >> carPrice;

            newCar.setVin(carVin);
            newCar.setMake(carMake);
            newCar.setModel(carModel);
            newCar.setYear(carYear);
            newCar.setPrice(carPrice);

            cout << newCar;

            vecDealer[i].setNumberOfCars(vecDealer[i].getNumberOfCars() + 1); //dealer's cars add 1
            Car *carArrayPtr = new Car[vecDealer[i].getNumberOfCars()]; //new pointer called

            for (int a = 0; a < vecDealer[i].getNumberOfCars() - 1; a++) { //copy into array
                carArrayPtr[a] = vecDealer[i].carArrayptr[a];
            }
            carArrayPtr[vecDealer[i].getNumberOfCars() - 1] = newCar; //put the user car at the end of array

            delete[] vecDealer[i].carArrayptr; // add delete function
            vecDealer[i].carArrayptr = carArrayPtr;

            for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++) { //print the cars
                cout << vecDealer[i].carArrayptr[j].getVin()<<endl;
                cout << vecDealer[i].carArrayptr[j].getMake()<<endl;
                cout << vecDealer[i].carArrayptr[j].getModel()<<endl;
                cout << vecDealer[i].carArrayptr[j].getYear()<<endl;
                cout << vecDealer[i].carArrayptr[j].getPrice()<<endl;
            }
            break;
        }
    }

    //if input incorrectly then display error
    if (!foundDealer) {
        cout << "Sorry, That Dealer Is Not Found. Please try again!" << endl;
    }
}

void sortCarDealer(vector <Dealer> &vecDealer){
    // display dealers
    // chose a dealer
    // sort dealer cars
    displayDealers(vecDealer);
    int userDealerNum;
    cout << "Choose a Dealer's number to sort by VIN:" << endl;
    cin >> userDealerNum;
    int i;
    for(i = 0; i < vecDealer.size(); i ++) {
        if(vecDealer[i].getDealerNumber() == userDealerNum) { //linear search for Dealer number
            for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++){
                for (int k = 0; k < vecDealer[i].getNumberOfCars()-i-1; k++){
                    // Comparing consecutive data and swapping values if value at j > j+1.
                    if (vecDealer[i].carArrayptr[k].getVin() > vecDealer[i].carArrayptr[k + 1].getVin()){
                        Car temp = vecDealer[i].carArrayptr[k + 1];
                        vecDealer[i].carArrayptr[k + 1] = vecDealer[i].carArrayptr[k];
                        vecDealer[i].carArrayptr[k] = temp;
                    }
                }
            }
            for (int j = 0; j < vecDealer[i].getNumberOfCars(); j++) { //if found, print all Cars
                cout << vecDealer[i].carArrayptr[j];
            }

            break;
        }
    }
    if(i == vecDealer.size()) { //if not found, asks to try again
        cout << "Invalid dealer number. Please try again." << endl;
    }


}

void writeFile (ofstream & outfile, vector<Dealer> &vecDealer ) {
    // write dealer and cars in a file in the same layout as the input file

    //open new file named out.txt
    cout << "Outputting to file 'out.txt'" << endl;
    outfile.open("out.txt");

    //create a loop where it inputs to out file
    for (int i = 0; i < vecDealer.size(); i++) {
        outfile << vecDealer[i].getDealerName() << endl;
        outfile << vecDealer[i].getDealerNumber() << endl;
        outfile << vecDealer[i].getNumberOfCars() << endl;

        for (int i = 0; i < vecDealer[i].getNumberOfCars(); i++) {
            outfile << vecDealer[i].carArrayptr[i].getVin() << endl;
            outfile << vecDealer[i].carArrayptr[i].getMake() << endl;
            outfile << vecDealer[i].carArrayptr[i].getModel() << endl;
            outfile << vecDealer[i].carArrayptr[i].getYear() << endl;
        }
    }
    outfile.close(); //close the file
    cout << "File successfully exported!" << endl;
}

// functions for search and sort
//===============================
void sortCar(Car * ptrCar, int size){
// you may use Selection or Bubble Sort, but no other than that. Use the algorithm we discussed in class

}
int searchDealer(vector <Dealer> &vecDealer, int searchValue ) {
// you may use linear or Binary search, it is your choice, but do not use any other kind of search
// return the index
    return 0;
}
int searchCar(Car *ptrCar, string searchValue, int size ){
// you may use linear or Binary search , it is your choice, but do not use any other kind of search
// return the index
    return 0;
}
