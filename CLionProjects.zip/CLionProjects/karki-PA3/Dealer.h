//
// Created by Iris Linck on 4/24/19.
//

#ifndef PA3SKELETON_DEALER_H
#define PA3SKELETON_DEALER_H

#include <string>
#include <iostream>
using namespace std;

// declare the name of the classes
class Dealer;
class Car;

class Dealer {
private:
    int dealerNumber;
    string dealerName;
    int numberOfCars = 0;

public:
    Dealer();  // default construction
    Dealer(int dealerNumber);

    int getDealerNumber() const;

    void setDealerNumber(int dealerNumber);

    const string &getDealerName() const;

    void setDealerName(const string &dealerName);

    int getNumberOfCars() const;

    void setNumberOfCars(int numberOfCars);

    Car * carArrayptr;

    friend ostream& operator<<(ostream &out, Dealer &d);

};

class Car {

private:
    string vin;
    string make;
    string model;
    int year;
    double price;


public:
    Car();  // default construction
    const string &getVin() const;

    void setVin(const string &vin);

    const string &getMake() const;

    void setMake(const string &make);

    const string &getModel() const;

    void setModel(const string &model);

    int getYear() const;

    void setYear(int year);

    double getPrice() const;

    void setPrice(double price);

    friend ostream& operator<<(ostream &out, Car &c);
};

#endif //PA3SKELETON_DEALER_H
