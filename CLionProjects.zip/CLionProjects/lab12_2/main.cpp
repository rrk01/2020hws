#include<iostream>
using namespace std;

class Date
{
public:
    Date();
    Date(int mm, int dd, int yy);

    void printDate();
    int getDay();
    int getMonth();
    int getYear();
    bool isLeapYear();
    int daysPassed();
    int daysLeft();
    int diff(Date AnotherDate);

    void setDay(int dd);
    void setMonth(int mm);
    void setYear(int yy);
private:
    int day;
    int month;
    int year;
};

Date::Date():month(1), day(1), year(1990){}
Date::Date(int mm, int dd, int yy):month(mm), day(dd), year(yy){}
void Date::setDay(int dd)
{
    day = dd;
}
void Date::setMonth(int mm)
{
    month = mm;
}
void Date::setYear(int yy)
{
    year = yy;
}

void Date::printDate()
{
    cout << month << "-" << day << "-" << year << endl;
}
int Date::getDay()
{
    return day;
}
int Date::getMonth()
{
    return month;
}
int Date::getYear()
{
    return year;
}
bool Date::isLeapYear() {
    bool x;
    if(year % 4 != 0) {
        x = false;
    }else if((year % 100 == 0) && (year % 400 != 0)) {
        x = false;
    }else{
        x = true;
    }
    if(x) {
        cout << year << " is a leap year." << endl;
    }else{
        cout << year << " is not a leap year." << endl;
    }
    return x;
}
int Date::daysPassed() {
    int p;
    switch(month) {
        case 1:
            p = 0;
            break;
        case 2:
            p = 31;
            break;
        case 3:
            p = 59;
            break;
        case 4:
            p = 90;
            break;
        case 5:
            p = 120;
            break;
        case 6:
            p = 151;
            break;
        case 7:
            p = 181;
            break;
        case 8:
            p = 212;
            break;
        case 9:
            p = 243;
            break;
        case 10:
            p = 273;
            break;
        case 11:
            p = 304;
            break;
        case 12:
            p = 334;
            break;
        default:
            cout << "bruh";
            break;
    }
    p += day;
    if(isLeapYear() && month != 1)
        p ++;
    if(p == 1)
        cout << p << " day has passed in this year" << endl;
    else
        cout << p << " days have passed in this year" << endl;
    return p;
}
int Date::daysLeft() {
    int l;
    if(isLeapYear())
        l = 366-daysPassed();
    else
        l = 365-daysPassed();
    if(l == 1)
        cout << l << " day is left for this year" << endl;
    else
        cout << l << " days are left for this year" << endl;
    return l;
}
int Date::diff(Date AnotherDate) {
    int a = AnotherDate.daysPassed() - daysPassed();
    if(a < 0)
        a += 365;
    cout << "Difference is: " << a << " days" << endl;
    return a;
}

int main() {
    int z,y,x,w,v,u;
    cin >> z >> y >> x >> w >> v >> u;
    Date Adate1(z,y,x);
    Date Adate2(w,v,u);
    Adate1.isLeapYear();
    Adate1.daysPassed();
    Adate1.daysLeft();
    Adate1.diff(Adate2);
}