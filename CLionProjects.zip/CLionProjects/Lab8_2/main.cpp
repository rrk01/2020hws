#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> items;
    int userIn;
    do {
        cin >> userIn;
        if(userIn >= 0)
            items.push_back(userIn);
    }while(userIn > 0);
    if(items.size()%2 == 1) {
        cout << items.at(items.size()/2) << endl;
    }else{
        cout << items.at(items.size()/2 - 1) << " " << items.at(items.size()/2) << endl;
    }
    return 0;
}