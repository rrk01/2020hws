#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    ifstream filestream;
    filestream.open("in.txt");
    int n;
    double avg = 0;
    int counter = 0;
    while(filestream >> n) {
        //filestream.ignore();
        avg += n;
        counter ++;
        cout << n << endl;
    }
    avg = avg/counter;
    cout << avg << endl;
    return 0;
}