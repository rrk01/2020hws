#include <iostream>
using namespace std;

int main() {

    int a;
    int b;
    int c;

    cin >> a >> b >> c;

    if(a > b && a > c) {
        cout << a;
    }else if(b > c && b > a) {
        cout << b;
    }else if(c > a && c > b) {
        cout << c;
    }else{
        cout << a;
    }

    return 0;
}