//
// Created by ryanr on 9/11/2019.
//

#ifndef KARKIHW2_POINT_H
#define KARKIHW2_POINT_H

#include <iostream>
using namespace std;

class point {
private:
    int x;
    int y;
public:
    point() : x(0), y(0) {}
    point(int x, int y) : x(x), y(y) {}

    int getX() const {
        return x;
    }

    void setX(int x) {
        point::x = x;
    }

    int getY() const {
        return y;
    }

    void setY(int y) {
        point::y = y;
    }
};

#endif //KARKIHW2_POINT_H
