Ryan Karki
107867709
main.cpp, rectangle class that includes point class
works completely