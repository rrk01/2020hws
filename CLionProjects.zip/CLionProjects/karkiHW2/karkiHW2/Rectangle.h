//
// Created by ryanr on 9/11/2019.
//

#ifndef KARKIHW2_RECTANGLE_H
#define KARKIHW2_RECTANGLE_H

#include <iostream>
#include "point.h"

class Rectangle {
private:
    point topLeft;
    point bottomLeft;
    point topRight;
    point bottomRight;
    int length;
    int width;
public:
    Rectangle() : topLeft(), bottomLeft(), topRight(), bottomRight(), length(0), width(0) {}
    Rectangle(int x, int y, int length, int width) : topLeft(x,y), length(length), width(width) { //constructor calculates all 4 points
        bottomLeft.setX(topLeft.getX());
        bottomLeft.setY(topLeft.getY() - length);

        topRight.setX(topLeft.getX() + width);
        topRight.setY(topLeft.getY());

        bottomRight.setX(topRight.getX());
        bottomRight.setY(bottomLeft.getY());
    }

    const point &getTopLeft() const {
        return topLeft;
    }

    void setTopLeft(const point &topLeft) {
        Rectangle::topLeft = topLeft;
    }

    int getLength() const {
        return length;
    }

    void setLength(int length) {
        Rectangle::length = length;
    }

    int getWidth() const {
        return width;
    }

    void setWidth(int width) {
        Rectangle::width = width;
    }

    bool overlap(Rectangle &b);

    const point &getBottomLeft() const;

    const point &getTopRight() const;

    const point &getBottomRight() const;
};

#endif //KARKIHW2_RECTANGLE_H
