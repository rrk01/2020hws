#include <iostream>
#include "point.h"
#include "Rectangle.h"
using namespace std;

int main() {
    //declaration of user inputs
    int userX, userX2;
    int userY, userY2;
    int userLength, userLength2;
    int userWidth, userWidth2;

    //user input for rectangle 1
    cout << "x of rectangle 1:" << endl;
    cin >> userX;
    cout << "y of rectangle 1:" << endl;
    cin >> userY;
    cout << "length of rectangle 1:" << endl;
    cin >> userLength;
    cout << "width of rectangle 1:" << endl;
    cin >> userWidth;

    //user input for rectangle 2
    cout << "x of rectangle 2:" << endl;
    cin >> userX2;
    cout << "y of rectangle 2:" << endl;
    cin >> userY2;
    cout << "length of rectangle 2:" << endl;
    cin >> userLength2;
    cout << "width of rectangle 2:" << endl;
    cin >> userWidth2;

    Rectangle a(userX, userY, userLength, userWidth);
    Rectangle b(userX2, userY2, userLength2, userWidth2);

    //display rectangle 1
    cout << "Coordinates of rectangle 1: ("
         << a.getTopLeft().getX() << "," << a.getTopLeft().getY() << ") ("
         << a.getBottomLeft().getX() << "," << a.getBottomLeft().getY() << ") ("
         << a.getBottomRight().getX() << "," << a.getBottomRight().getY() << ") ("
         << a.getTopRight().getX() << "," << a.getTopRight().getY() << ")" << endl;

    //display rectangle 2
    cout << "Coordinates of rectangle 2: ("
         << b.getTopLeft().getX() << "," << b.getTopLeft().getY() << ") ("
         << b.getBottomLeft().getX() << "," << b.getBottomLeft().getY() << ") ("
         << b.getBottomRight().getX() << "," << b.getBottomRight().getY() << ") ("
         << b.getTopRight().getX() << "," << b.getTopRight().getY() << ")" << endl;

    //check if Rectangle a intersects Rectangle b
    if(a.overlap(b))
        cout << "They intersect." << endl;
    else
        cout << "They do not intersect." << endl;

    return 0;
}