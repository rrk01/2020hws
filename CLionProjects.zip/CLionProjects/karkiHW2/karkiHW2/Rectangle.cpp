//
// Created by ryanr on 9/11/2019.
//

#include <iostream>
#include "Rectangle.h"

bool Rectangle::overlap(Rectangle &b) { //check if current Rectangle intersects with another Rectangle object

    // If one rectangle is on left side of other
    if (topLeft.getX() > b.bottomRight.getX() || b.topLeft.getX() > bottomRight.getX())
        return false;

    // If one rectangle is above other
    if (topLeft.getY() < b.bottomRight.getY() || b.topLeft.getY() < bottomRight.getY())
        return false;

    return true;
}

const point &Rectangle::getBottomLeft() const {
    return bottomLeft;
}

const point &Rectangle::getTopRight() const {
    return topRight;
}

const point &Rectangle::getBottomRight() const {
    return bottomRight;
}
