#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> userList;
    vector<int> smaller;
    int start;
    cin >> start;
    int temp;
    for (int i = 0; i < start; i ++) {
        cin >> temp;
        userList.push_back(temp);
    }
    for(int j = 0; j < start; j ++) {
        if(userList.at(j) <= userList.at(start-1)) {
            smaller.push_back(userList.at(j));
            cout << userList.at(j) << " ";
        }
    }
    cout << endl;
    return 0;
}