// main.cpp
// PA2_Outline_Template
// Created by Iris Linck on 1/17/19.
// Copyright Â© 2019 Iris Linck. All rights reserved.

/* NAME: Ryan Karki
 * CLASS: CSCI1410
 * DESCRIPTION: 8 ball.
 * STATUS: Not running, just an outline
 */

#include <iostream>     // needed for using cin/cou statments
#include <string>       // needed for using string type
#include <fstream>      // needed for using files

using namespace std;

// function prototypes
void readResponses(ifstream &infile, string responses[], string categories[], const int MAXSIZE, int &size );
void playMagicEightBall(string responses[], string categories[], int size );
void sortByResponses(string responses[], string categories[] , int size);
void sortByCategories(string responses[], string categories[], int size );
void writeMagicResponseCategories (ofstream &outfile, string responses[], string categories[], int size);
void deleteMagicResponse(string responses[], string categories[], int &size);
void addMagicResponse(string responses[], string categories[], int &size, const int MAXSIZE);
//

int main() {
    /* Menu shows up
     * User enters letter a - e (capital or lowercase)
     * A. call readResponses
     * B. call playMagicEightBall
     * C. call sortByResponses
     * D. call sortByCategories
     * E. call writeMagicResponseCategories
     */
    return 0;
}

// function headers and bodies
void readResponses(ifstream &infile, string responses[], string categories[], const int MAXSIZE, int &size ){
    /* read first line of file, put in responses
     * read second line of file, put in categories
     * alternate like so - every other line goes in responses and categories respectively
     */
}
void playMagicEightBall(string responses[], string categories[], int size ){
    // takes user input, responds with a response
}
void sortByResponses(string responses[], string categories[] , int size){
    // sort responses alphabetically
    // print each response followed by its category
}
void sortByCategories(string responses[], string categories[], int size ){
    // sort Positive > Vague > Negative
    // print each category followed by its response
}
void writeMagicResponseCategories (ofstream &outfile, string responses[], string categories[], int size){
    // output to outfile
    // read instance of responses[], end line
    // then read instance of categories[], end line
}
void deleteMagicResponse(string responses[], string categories[], int &size){
    // plain English
}
void addMagicResponse(string responses[], string categories[], int &size, const int MAXSIZE){
    // plain English
}