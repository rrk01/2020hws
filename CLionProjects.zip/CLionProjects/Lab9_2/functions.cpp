//
// Created by ryanr on 7/26/2019.
//

#include <iostream>

#include "functions.h"

void printArray(int arr[], int size)

{

    for (int i = 0; i < size; i++)

    {

        std::cout << arr[i] << " ";

    }

    std::cout << std::endl;

}

// Ensure you only print to size NOT MAXSIZE!

void sort(int arr[], int size)

{

    for (int i = 0; i < size; i++)

    {

        for (int j = i; j < size; j++)

        {

            if (arr[i] > arr[j])

            {

                int temp = arr[i];

                arr[i] = arr[j];

                arr[j] = temp;

            }

        }

    }

}

// Arrays are passed by reference so changes in the function to arr will make changes to the array from the calling function (main)

void sortThenTwoSmallest(int arr[], int size)

{

    sort(arr, size);

    std::cout << arr[0] << " " << arr[1] << std::endl;

}

// Calls sort, and OK to change the order of arr in the calling function

// (main.cpp)