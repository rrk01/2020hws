//
// Created by ryanr on 7/26/2019.
//

#ifndef LAB9_2_FUNCTIONS_H
#define LAB9_2_FUNCTIONS_H
void printArray(int arr[ ], int size);
// Ensure you only print to size NOT MAXSIZE!

void sort(int arr[ ], int size);
//Arrays are passed by reference so changes in the function to arr will make changes to the array from the calling function (main)

void sortThenTwoSmallest (int arr[ ], int size);
// Calls sort, and OK to change the order of arr in the calling function (main.cpp)
#endif //LAB9_2_FUNCTIONS_H
