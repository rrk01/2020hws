#include<iostream>

#include<fstream>

#include "functions.h"

using namespace std;

#define MAXSIZE 50

int main(){

    ifstream in;

    in.open("in9.2.txt");

    if(in.fail()){

        cout<<"Unable to open file"<<endl;

        return -1;

    }

    int arr[MAXSIZE], i=0;

    while(!in.eof()){

        in>>arr[i];

        i++;

    }

    printArray(arr, i);

    sortThenTwoSmallest(arr, i);

    return 0;

}