//
// Created by ryanr on 7/27/2019.
//
#include <iostream>
#include <string>
#include <fstream>
#include "functions.h"
using namespace std;
// function headers and bodies

void printMenu() {
    cout << "Pick an option:" << endl;
    cout << "a. Read responses/categories from a file named 'magic.txt'" << endl;
    cout << "b. Play Magic Eight Ball" << endl;
    cout << "c. Sort by responses" << endl;
    cout << "d. Sort by categories" << endl;
    cout << "e. Write responses/categories to a file" << endl;
    cout << "f. Delete response" << endl;
    cout << "g. Add response" << endl;
    cout << "Type 'quit' to exit the program." << endl << endl;
}
void readResponses(ifstream &infile, string responses[], string categories[], const int MAXSIZE, int &size){
    /* read first line of file, put in responses
     * read second line of file, put in categories
     * alternate like so - every other line goes in responses and categories respectively
     */
    cout << "Reading file..." << endl;
    int count = 0;
    string getResponse;
    infile.open("magic.txt");
    while(getline(infile,getResponse) && count < MAXSIZE) {
        if(count % 2 == 0) {
            responses[count/2] = getResponse;
        }else{
            categories[count/2] = getResponse;
        }
        count ++;
    }
    infile.close();
    size = count/2;
    cout << "Size = " << size << endl; //uncomment to debug
    for(int i = 0; i < size; i ++) {
        cout << responses[i] << " ";
        cout << categories[i] << endl;
    }
    cout << "File successfully imported!" << endl << endl;
}
void playMagicEightBall(string responses[], string categories[], int size ){
    // takes user input, responds with a response
    string userQuestion;
    cout << "Let's play magic 8-ball! Please ask a yes or no question." << endl;
    cin.ignore();
    getline(cin, userQuestion);
    if(userQuestion.length() == 0) {
        cout << "Question length 0. Please try again." << endl;
    }else if(userQuestion.at(userQuestion.length()-1) == '?') {
        cout <<  ">> " << responses[rand()%size] << " <<" << endl << endl;
    }else{
        cout << "That's not a question! Please end your phrase with a question mark (?)." << endl;
    }
}
void sortByResponses(string responses[], string categories[] , int size){
    // sort responses alphabetically
    // print each response followed by its category
    for (int i = 0; i < size; i++){
        for (int j = 0; j < size-i-1; j++){
            // Comparing consecutive data and swapping values if value at j > j+1.
            if (responses[j] > responses[j+1]){
                string temp = responses[j + 1];
                string temp2 = categories[j + 1];
                responses[j + 1] = responses[j];
                categories[j + 1] = categories[j];
                responses[j] = temp;
                categories[j] = temp2;
            }
        }
    }
    for(int i = 0; i < size; i ++) {
        cout << responses[i] << " " << categories[i] << endl;
    }
}
void sortByCategories(string responses[], string categories[], int size ){
    // sort Positive > Vague > Negative
    // print each category followed by its response
    for (int i = 0; i < size; i++){
        for (int j = 0; j < size-i-1; j++){
            // Comparing consecutive data and swapping values if value at j > j+1.
            if (categories[j] > categories[j+1]){
                string temp = categories[j + 1];
                string temp2 = responses[j + 1];
                categories[j + 1] = categories[j];
                responses[j + 1] = responses[j];
                categories[j] = temp;
                responses[j] = temp2;
            }
        }
    }
    for(int i = 0; i < size; i ++) {
        cout << categories[i] << " " << responses[i] << endl;
    }
}
void writeMagicResponseCategories (ofstream &outfile, string responses[], string categories[], int size){
    // output to outfile
    // read instance of responses[], end line
    // then read instance of categories[], end line
    string userWrite;
    outfile.open("magic.txt",ios::app);
    cout << "Please enter a 8-ball response." << endl;
    cin.ignore();
    getline(cin,userWrite);
    outfile << "\n";
    outfile << userWrite << "\n";
    cout << "Please enter a category (positive, vague, negative)." << endl;
    getline(cin,userWrite);
    outfile << userWrite;
    outfile.close();
}
void deleteMagicResponse(string responses[], string categories[], int &size){
    // plain English
}
void addMagicResponse(string responses[], string categories[], int &size, const int MAXSIZE){
    // plain English
}