//
// Created by ryanr on 7/27/2019.
//
#ifndef KARKI_PA2_FUNCTIONS_H
#define KARKI_PA2_FUNCTIONS_H
#include <string>
#include <fstream>
using namespace std;

void printMenu();
void readResponses(ifstream &infile, string responses[], string categories[], const int MAXSIZE, int &size);
void playMagicEightBall(string responses[], string categories[], int size );
void sortByResponses(string responses[], string categories[] , int size);
void sortByCategories(string responses[], string categories[], int size );
void writeMagicResponseCategories (ofstream &outfile, string responses[], string categories[], int size);
void deleteMagicResponse(string responses[], string categories[], int &size);
void addMagicResponse(string responses[], string categories[], int &size, const int MAXSIZE);
#endif //KARKI_PA2_FUNCTIONS_H
