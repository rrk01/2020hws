/* NAME: Ryan Karki
 * CLASS: CSCI1410
 * DESCRIPTION: 8 ball.
 * STATUS: Ready. Press start to begin.
 */

#include <iostream>     // needed for using cin/cou statments
#include <string>       // needed for using string type
#include <fstream>      // needed for using files
#include "functions.h"

using namespace std;

int main() {
    const int MAXSIZE = 100;
    srand(1);
    int size = 0;
    string userMenuSelection = "null";
    ifstream infile;
    ofstream outfile;
    string responses[MAXSIZE];
    string categories[MAXSIZE];
    cout << "Welcome to Magic 8-ball!" << endl << endl;
    while(userMenuSelection != "quit") {
        printMenu();
        cin >> userMenuSelection;
        if(userMenuSelection == "A" || userMenuSelection == "a") { //if user selects A
            readResponses(infile,responses,categories,MAXSIZE,size); //imports file
        }else if(userMenuSelection == "B" || userMenuSelection == "b") { //if user selects B
            if (size == 0) { //if arrays don't exist
                cout << "Please import a file named 'magic.txt' (option A)!" << endl << endl; //print menu again
                continue;
            }
            playMagicEightBall(responses, categories, size); //otherwise, play ball!
        }else if(userMenuSelection == "C" || userMenuSelection == "c") {
            sortByResponses(responses,categories,size);
        }else if(userMenuSelection == "D" || userMenuSelection == "d") {
            sortByCategories(responses, categories, size);
        }else if(userMenuSelection == "E" || userMenuSelection == "e") {
            writeMagicResponseCategories(outfile,responses,categories,size);
            readResponses(infile,responses,categories,MAXSIZE,size);
        }
    }
    cout << "Thank you for playing! Goodbye." << endl;
    return 0;
}