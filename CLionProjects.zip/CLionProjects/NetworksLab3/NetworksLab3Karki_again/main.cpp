#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <math.h>
#include <chrono>
#include <ctime>

using namespace std;

int minKey(int key[], bool mstSet[], int V)
{
    // Initialize min value
    int min = INT_MAX, min_index;

    for (int v = 0; v < V; v++)
        if (mstSet[v] == false && key[v] < min)
            min = key[v], min_index = v;

    return min_index;
}

void printMST(int parent[], vector<vector<int>> graph, int V)
{
    cout<<"Edge\tWeight\n";
    int minimumCost = 0;
    for (int i = 1; i < V; i++) {
        cout << "(" << parent[i] << ", " << i << ")\t" << graph[i][parent[i]] << endl;
        minimumCost += graph[i][parent[i]];
    }
    cout << "Minimum cost = " << minimumCost << endl;
}

void primsAlgorithm(vector<vector<int>> graph, int V)
{
    // Array to store constructed MST
    int parent[V];

    // Key values used to pick minimum weight edge in cut
    int key[V];

    // To represent set of vertices not yet included in MST
    bool mstSet[V];

    // Initialize all keys as INFINITE
    for (int i = 0; i < V; i++)
        key[i] = INT_MAX, mstSet[i] = false;

    // Always include first 1st vertex in MST.
    // Make key 0 so that this vertex is picked as first vertex.
    key[0] = 0;
    parent[0] = -1; // First node is always root of MST

    // The MST will have V vertices
    for (int count = 0; count < V - 1; count++)
    {
        // Pick the minimum key vertex from the
        // set of vertices not yet included in MST
        int u = minKey(key, mstSet, V);

        // Add the picked vertex to the MST Set
        mstSet[u] = true;

        // Update key value and parent index of
        // the adjacent vertices of the picked vertex.
        // Consider only those vertices which are not
        // yet included in MST
        for (int v = 0; v < V; v++)

            // graph[u][v] is non zero only for adjacent vertices of m
            // mstSet[v] is false for vertices not yet included in MST
            // Update the key only if graph[u][v] is smaller than key[v]
            if (graph[u][v] && mstSet[v] == false && graph[u][v] < key[v])
                parent[v] = u, key[v] = graph[u][v];
    }
    printMST(parent, graph, V);
}

int main() {
    string filename;
    int vertices; //no. of vertices in graph

    cout << "Enter file name:";
    cin >> filename;

    auto start = chrono::system_clock::now(); //to compute time elapsed

    ifstream infile;
    infile.open(filename);
    infile >> vertices;

    int inputMST[vertices*vertices][3]; //array to store MST data from file
    vector<vector<int>> convertedMST(vertices,vector<int>(vertices,0)); //array to store MST in a converted format

    //load MST array from file
    int a, b, c;
    int counter = 0;
    while (infile >> a >> b >> c){
        if(a == 1073741824)
            a = 0;
        if(b == 1073741824)
            b = 0;
        if(c == 1073741824)
            c = 0;
        inputMST[counter][0] = a;
        inputMST[counter][1] = b;
        inputMST[counter][2] = c;
        counter ++;
    }

    /*
    //print file
    for(int j = 0; j < sizeof(inputMST)/sizeof(inputMST[0]); j ++) {
        for(int k = 0; k < 3; k ++) {
            cout << inputMST[j][k] << "\t";
        }
        cout << endl;
    }
    */

    //convert to more readable graph
    for(int i = 0; i < sizeof(inputMST)/sizeof(inputMST[0]); i ++) {
        convertedMST[int(i/vertices)][i%6] = inputMST[i][2];
    }


    /*
    //print converted MST
    for(int j = 0; j < vertices; j ++) { //print file
        for(int k = 0; k < vertices; k ++) {
            cout << convertedMST[j][k] << "\t";
        }
        cout << endl;
    }
    */


    primsAlgorithm(convertedMST, vertices);

    auto end = chrono::system_clock::now();

    chrono::duration<double> elapsed_seconds = end-start;
    std::time_t end_time = chrono::system_clock::to_time_t(end);

    std::cout << "Total Execution Time: " << elapsed_seconds.count()*1000 << "ms\n";

    infile.close();
    return 0;
}