Lab 3 Minimum Spanning Tree

input: file name
output: minimum spanning tree, minimum cost, run time