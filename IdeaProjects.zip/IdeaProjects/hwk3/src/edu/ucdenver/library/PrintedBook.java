package edu.ucdenver.library;

public class PrintedBook {
}
