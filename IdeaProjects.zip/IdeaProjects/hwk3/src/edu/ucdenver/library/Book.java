package edu.ucdenver.library;

import java.time.LocalDate;

public class Book {
    private String title;
    private LocalDate publicationDate;
    private String[] otherTitles;
    private String isbn;
    private A
}
