package edu.ucdenver.library;

public class EBook {

}
