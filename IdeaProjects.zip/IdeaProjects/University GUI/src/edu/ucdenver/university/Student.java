package edu.ucdenver.university;

import java.time.LocalDate;
import java.util.ArrayList;

public abstract class Student implements Comparable<Student> {
    private String name;
    private LocalDate dob;
    private String email;
    private String id;
    private ArrayList<Course> studentCourses;

    public Student(String name, LocalDate dob, String id){
        this.name = name;
        this.dob = dob;
        this.email = name.toLowerCase().replace(" ",".")+"@ucdenver.edu";
        this.id = id;
        studentCourses = new ArrayList<Course>();
    }

    @Override
    public String toString(){
        return String.format("%-20s - %s - %-50s - Standing: %s",this.getName(), this.getDob(), this.getEmail(),
                this.getStanding());
    }
    public void enrollTo(Course newCourse){
        this.studentCourses.add(newCourse);
    }

    public abstract String getStanding();

    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public LocalDate getDob(){
        return dob;
    }
    public void setDob(LocalDate dob){
        this.dob = dob;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public int compareTo(Student o) {
        return this.getName().compareTo(o.getName());
    }

    public int compareStanding(Student o){
        if(o.getStanding().equals("Undergraduate"))
            return 0;
        else if(o.getStanding().equals("Master"))
            return 1;
        else if(o.getStanding().equals("PhD"))
            return 2;
        else
            return 3;
    }
}
