package edu.ucdenver.university;

import java.util.ArrayList;
import java.time.LocalDate;
import java.util.Map;
// import java.util.comparator;

public class University {
    private ArrayList<Student> students;
    private ArrayList<Course> courses;

    public University(){
        this.students = new ArrayList<>(100);
        this.courses = new ArrayList<>(100);
    }

    @Override
    public String toString(){
        return String.format("University with %d students and %d courses.", this.getStudents().size(),
                this.getCourses().size());

    }
    public Student getStudent(String name) throws IllegalArgumentException{
        for (Student s:students){
            if(s.getName().equalsIgnoreCase(name)){
                return s;
            }
        }
        throw new IllegalArgumentException("Student not in the university.");

    }
    public Course getCourse(String subject, int number) throws IllegalArgumentException{
        for (Course c: courses){
            if(c.getSubject().equalsIgnoreCase(subject) && c.getNumber()==number){
                return c;
            }
        }
        throw new IllegalArgumentException("Course not in Subjects.");
    }
    public void addUndergrad(String name, LocalDate dob, String id){
        students.add(new Undergraduate(name,dob,id));
    }
    public void addMaster(String name, LocalDate dob, String id){
        students.add(new Master(name,dob,id));
    }
    public void addPhD(String name, LocalDate dob, String id, String topic){
        students.add(new PhD(name,dob,id,topic));
    }

    public void addCourse(String subject, int number, String title) throws IllegalArgumentException{
        try{
            this.getCourse(subject,number);
        }
        catch(IllegalArgumentException iae){
            this.courses.add(new Course(subject,number,title));
            return;
        }
        throw new IllegalArgumentException("The course is already in the Subjects.");
    }
    public void enrollStudentToCourse(String name, String courseName, int courseNum) throws IllegalArgumentException{
            for(Student s:students){
                if(s.getName().equalsIgnoreCase(name)){
                    for(Course c:courses){
                        if(c.getSubject().equalsIgnoreCase(courseName)&&c.getNumber()==courseNum){
                            s.enrollTo(c);
                            return;
                        }
                    }
                }
            }
        throw new IllegalArgumentException("Student or Course do not exist.");



    }
    public ArrayList<Course> getCourses() {
        return courses;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void sortStudents() {
        int n = students.size();
        for (int i = 0; i < n-1; i++)
            for (int j = 0; j < n-i-1; j++)
                if (students.get(j).compareTo(students.get(j + 1)) > 0)
                {
                    // swap students[j+1] and students[j] 
                    Student temp = students.get(j);
                    students.set(j, students.get(j + 1));
                    students.set(j + 1, temp);
                }
    }

    public Object[][] countStudentsPerStanding() {
        Object[][] counts = {{"Master", "PhD", "Undergraduate"}, {0, 0, 0}};
        for(Student s: students) {
            if(s.getStanding() == "Master")
                //counts[0][1] = counts[0][1] + 1;
        }


    }
}
