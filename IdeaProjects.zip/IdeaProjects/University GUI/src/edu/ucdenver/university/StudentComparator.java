package edu.ucdenver.university;

import java.time.LocalDate;
import java.util.Comparator;

public class StudentComparator extends Student{

    public StudentComparator(String name, LocalDate dob, String id) {
        super(name, dob, id);
    }

    @Override
    public String getStanding() {
        return null;
    }

    @Override
    public int compareTo(Student o) {
        if(this.compareStanding(o) > 0)
            return 1;
        else if(this.compareStanding(o) < 0)
            return -1;
        else
            return this.getName().compareTo(o.getName());
    }
}
