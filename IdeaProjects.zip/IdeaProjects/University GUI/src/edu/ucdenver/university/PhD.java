package edu.ucdenver.university;

import java.time.LocalDate;

public class PhD extends Graduate{
    private String dissertationTopic;

    public PhD(String name, LocalDate dob, String id, String dissertationTopic){
        super(name,dob,id);
        this.dissertationTopic = dissertationTopic;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(String.format(" - Dissertation is about %s",this.getDissertationTopic()));
        return sb.toString();
    }
    @Override
    public String getStanding(){
        return "PhD";
    }

    public String getDissertationTopic() {
        return dissertationTopic;
    }
}
