package edu.ucdenver.university;

import java.util.ArrayList;

public class Course {
    private String subject;
    private int number;
    private String title;
    private ArrayList<Student> courseStudents;

    public Course(String subject, int number, String title){
        this.subject = subject.toUpperCase();
        this.number = number;
        this.title = title;
        this.courseStudents = new ArrayList<Student>();
    }
    public void addStudentToCourse(Student newStudent){
        this.courseStudents.add(newStudent);
    }
    public ArrayList<Student> getEnrolledStudents(){
        return courseStudents;
    }
    @Override
    public String toString() {
        return String.format("%s%04d - %s",this.subject,this.number, this.title);
    }
    public String getSubject(){
        return subject;
    }
    public int getNumber() {
        return number;
    }
    public String getTitle() {
        return title;
    }
}
