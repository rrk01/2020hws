import java.util.Calendar;

public class HealthRecord {
    private String fName;
    private String lName;
    private char gender;
    int dobDay;
    int dobMonth;
    int dobYear;
    int height;
    int weight;

    public HealthRecord(String fName, String lName, char gender, int dobDay, int dobMonth, int dobYear, int height, int weight) {
        this.fName = fName;
        this.lName = lName;
        this.gender = gender;
        this.dobDay = dobDay;
        this.dobMonth = dobMonth;
        this.dobYear = dobYear;
        this.height = height;
        this.weight = weight;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getDobDay() {
        return dobDay;
    }

    public int getDobMonth() {
        return dobMonth;
    }

    public int getDobYear() {
        return dobYear;
    }

    public void setDob(int day, int month, int year) {
        dobDay = day;
        dobMonth = month;
        dobYear = year;
    }

    public int getAge() {
        return Calendar.getInstance().get(Calendar.YEAR) - dobYear;
    }

    public int getMaximumHeartRate() {
        return 220 - getAge();
    }

    public String getTargetHeartRate() {
        return .5 * getMaximumHeartRate() + " - " + .85 * getMaximumHeartRate();
    }

    public float getBMI() {
        return ((float)703*getWeight())/((float)getHeight()*getHeight());
    }

    public String toString() {
        return "Name: " + this.lName + ", " + this.fName + ".\t Gender:" + this.gender + "\t DOB:" + this.dobMonth + "/" + this.dobDay + "/" + this.dobYear + "\t AGE:" + getAge() + "\t H:" + this.height + "in.\t W:" + this.weight + "lb.,\t MHR:" + getMaximumHeartRate() + ",\t THR:" + getTargetHeartRate() + ",\t BMI:" + getBMI();
    }

    public static void main(String args[]) {
        HealthRecord hr;
        hr = new HealthRecord("John","Doe",'M', 1,3,1990,70,180);
        System.out.println(hr);
        hr = new HealthRecord("Jane","Doe",'F', 20,5,1995,60,150);
        System.out.println(hr);
    }
}
