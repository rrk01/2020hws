public class DiamondPrinting {

    static String getCharSequence(String a, int b) {
        String newString = "";
        for(int i = 0; i < b; i ++) {
            newString = newString + a;
        }
        return newString;
    }

    static String getDiamond(int a) {
        if(a%2 == 0)
            return "";

        String output = "";
        int spaces = a/2;
        for(int i = 1; i < a; i += 2) {
            for(int j = 0; j < spaces; j ++)
                output += " ";
            output += getCharSequence("*", i);
            output += "\n";
            spaces --;
        }

        output += getCharSequence("*", a);
        output += "\n";
        spaces ++;

        for(int i = a-2; i >= 0; i -= 2) {
            for(int j = spaces-1; j >= 0; j --)
                output += " ";
            output += getCharSequence("*", i);
            output += "\n";
            spaces ++;
        }
        return output;
    }

    public static void main(String args[]) {
        DiamondPrinting diamondPrinter = new DiamondPrinting();
        System.out.println(diamondPrinter.getDiamond(7));
    }
}
