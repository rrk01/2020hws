public class PythagoreanTriples {

    static void triples(int aMin,int bMin,int cMin,int aMax,int bMax,int cMax) {
        int largest = 0;

        if(aMax > bMax && aMax > cMax) {
            largest = aMax;
        }else if(bMax > aMax && bMax > cMax) {
            largest = bMax;
        }else{
            largest = cMax;
        }

        int[][] arr = new int[3][largest];
        int count = 0;
        for(int i = aMin; i < aMax; ++ i) {
            for(int j = bMin; j < bMax; ++ j) {
                for(int k = cMin; k < cMax; ++ k) {
                    if(i*i + j*j == k*k) {
                        arr[0][count] = i;
                        arr[1][count] = j;
                        arr[2][count] = k;
                        ++ count;
                    }
                }
            }
        }

        for(int i = 0; i < largest; i ++) {
            for(int j = 0; j < 3; j ++) {
                if(arr[j][i] != 0)
                    System.out.print(arr[j][i] + " ");
            }
            if(arr[0][i] == 0)
                break;
            System.out.println();
        }
    }

    public static void main(String args[]) {
        triples(1,2,3,100,10,20);
    }
}
