package edu.cudenver.concurrent;

import java.util.Map;

//TODO: Make this a thread.
public class WordCount {
    private final String filename;
    private final Map<String,Integer> wordCount;

    /**
     * Initializes the map to store the word count.
     */
    public WordCount(String filename, String filename1, Map<String, Integer> wordCount){
        this.filename = filename1;
        //TODO: Initialize the instance variables.
        this.wordCount = wordCount;
    }

    /**
     * Given a line counts the words and update the map
     * @param line line to inspect
     */
    private void countWords(String line){
         //TODO: Count the words in the line, and update the instance variable map.
    }


    public Map<String,Integer> getWordCount(){
        return this.wordCount;
    }


    /*
    * TODO: Implement the methods to execute in the thread.
    *  In summary: open the file, read the lines, and for each line count the words.
    *
    * */


}
