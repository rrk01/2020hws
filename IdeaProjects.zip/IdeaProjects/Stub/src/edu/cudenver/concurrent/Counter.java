package edu.cudenver.concurrent;

import java.util.Map;

public class Counter {
    private final String filePath;
    private final Map<String, Integer> totalWordCount;

    public Counter(String filePath, String filePath1, Map<String, Integer> totalWordCount){
        this.filePath = filePath1;
        /*
         * TODO: Initialize the instance variable properly.
         * */
        this.totalWordCount = totalWordCount;
    }

    /**
     * Process all files in the filepath.
     */
    public void processFiles() {
        /* TODO: implement process File - Concurrent
        *
        * Intuition: For each file, create a thread to count the words in that file.
        *
        * Define a list of Word Count threads. We will need to store the objects so once the file was processes
        * we can get the map with the count of words for each file.
        *
        *
        *
        * Scan the files on the given path.
        * If there are files,
        *   Get an executor service
        *   for each filename
        *    create a wordcount thread for the filename
        *    add  the thread to the instance's list of threads
        *    start the thread with the executor service
        *
        *   After adding a thread for each file :
        *   shutdown the executor service and wait for the threads to finish (or up to 5 minutes).
        *
        *   Once all threads are done, for each word count thread in the list, update the total word count map
        *   in the instance with the map of each word count object.
        *
        * In case of no file was obtain, report an error
         */

    }

    /**
     * Returns the total Word Count map
     * @return returns the total word count map
     */
    public Map<String, Integer> getTotalWordCount() {
        return totalWordCount;
    }


    /**
     * Appends the counts from Map 2 into Map 1.
     * @param map1 first main map. This map object will be updated with map2
     * @param map2 map to add to map1
     */
    private void updateMap(Map<String, Integer> map1,Map<String, Integer> map2 ){
        /*
        * TODO: Make this method thread-safe!
        * */
        for (Map.Entry<String,Integer> entry : map2.entrySet()) {
            if (map1.containsKey(entry.getKey())) {
                int count = map1.get(entry.getKey());
                map1.put(entry.getKey(), count + entry.getValue());
            }
            else {
                map1.put(entry.getKey(), entry.getValue());
            }
        }
    }
}
