package edu.ucdenver.library;
import java.time.LocalDate;
import java.util.ArrayList;

public class Library {
    /** TODO:        Declare the instance attributes for the Library.
     * Follow the software engineering practices discussed in our videos.
     * Review the provided uml to identify data types.
     * - library name
     * - list of books
     * - list of authors
     *
     * Hint: use ArrayList for lists.
     */

    private String name;
    public ArrayList<Book> listOfBooks = new ArrayList<Book>();
    public ArrayList<Author> listOfAuthors = new ArrayList<Author>();

    public Library(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void printAuthors() {
        System.out.println("Printing authors:");
        System.out.println(listOfAuthors);
    }

    public void printBooks() {
        System.out.println("Printing books:");
        System.out.println(listOfBooks);
    }

    public void addBook(String title, LocalDate datePublished, String[] otherTitles, int numPages, String authorName)
            throws IllegalArgumentException { //Todo: observe this line. It's notifying clients that this method may throw an exception. (no code needed)
        /**
         *   TODO:
         *   Search to retrieve the author object based on the name.
         *      Basically for each author compare the name. remember to use str1.equals(str2) to compare strings.
         *      If found, use keep it and terminate the search.
         *   If the author doesn't exist, throw a IllegalArgumentException notifiying that.
         *
         *   Create the book object using the book constructor.
         *   add the book to the list.
         *
         *   NOTE: object (reference) variables should be initialized with null. and you can ask if var == null
          */
        int i;
        for(i = 0; i < listOfAuthors.size(); i ++) {
            if (listOfAuthors.get(i).getName().equals(authorName)) {
                listOfBooks.add(new Book(title, datePublished, otherTitles, listOfAuthors.get(i), numPages));
                //System.out.println("Book added!");
                break;
            }
        }

        if(i >= listOfAuthors.size())
            throw new IllegalArgumentException("Author does not exist.");



    }

    public void addAuthor(String name) throws IllegalArgumentException{
        for(int i = 0; i < listOfAuthors.size(); i ++)
            if(listOfAuthors.get(i).getName().equals(name))
                throw new IllegalArgumentException("Author already exists.");
        listOfAuthors.add(new Author(name));
    }

    public String toString(){
        String l = ""; //l for library
        l += "This is the " + this.name + " library.\n";
        l += "= Author List =\n";

        for(int i = 0; i < this.listOfAuthors.size(); i ++)
            l += listOfAuthors.get(i) + "\n";

        l += "= Book List =\n";

        for(int i = 0; i < this.listOfBooks.size(); i ++)
            l += listOfBooks.get(i).toString() + "\n";

        l += "--o--";

        return l;
    }
}
