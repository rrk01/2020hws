package edu.ucdenver.library;

import java.time.LocalDate;

public class Book {
    private String title;
    private LocalDate publicationDate;
    private String[] otherTitles;
    private int numPages;
    private Author bookAuthor;

    public Book() {
        this.title = "";
        this.publicationDate = null;
        this.otherTitles = null;
        this.numPages = -1;
        this.bookAuthor = null;
    }

    public Book(String title, LocalDate publicationDate, String[] otherTitles, Author bookAuthor, int numPages) {
        this.title = title;
        this.publicationDate = publicationDate;
        this.otherTitles = otherTitles;
        this.bookAuthor = bookAuthor;
        this.numPages = numPages;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(LocalDate publicationDate) {
        this.publicationDate = publicationDate;
    }

    public String[] getOtherTitles() {
        return otherTitles;
    }

    public void setOtherTitles(String[] otherTitles) {
        this.otherTitles = otherTitles;
    }

    public int getNumPages() {
        return numPages;
    }

    public void setNumPages(int numPages) {
        this.numPages = numPages;
    }

    public String toString(){
        String b = ""; //b for book
        b += "Book: " + this.title + ", ";
        b += "with " + this.numPages + " pages ";
        b += "published on " + this.publicationDate + " ";
        b += "written by " + this.bookAuthor.getName() + ".\n";

        for(int i = 0; i < this.otherTitles.length; i ++)
            b += "---a.k.a:" + this.otherTitles[i]  + "\n";

        return b;
    }
}
