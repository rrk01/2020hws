package edu.ucdenver.library;

public class Author {
    private String name;
    private int id;
    static private int count = 0;

    public Author(String name) {
        this.name = name;
        id = this.count;
        count ++;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString(){
        //Todo: Should return "name (Author)"  where name is the author's name
        return name + " (Author)";
    }
}
