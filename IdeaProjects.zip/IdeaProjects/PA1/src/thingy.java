import java.time.LocalDate;

public class thingy {
    private String authorName;
    private LocalDate publicationData;
    private int edition;

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public LocalDate getPublicationData() {
        return publicationData;
    }

    public void setPublicationData(LocalDate publicationData) {
        this.publicationData = publicationData;
    }

    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    public thingy(String authorName, LocalDate publicationData, int edition) {
        this.authorName = authorName;
        this.publicationData = publicationData;
        this.edition = edition;
    }
}
