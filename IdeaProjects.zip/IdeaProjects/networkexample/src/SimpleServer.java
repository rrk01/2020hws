import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.BufferedReader;

public class SimpleServer {
    public static void main(String[] args) {
        /*
        Binding and Listening - done
        Accepting Connections - done
        Send text
        Receive text
        */
        try {
            ServerSocket serverSocket = new ServerSocket(10001, 5);
            Socket clientConnection = null;

            while(true) {
                try {
                    System.out.println("Waiting for connection...");
                    clientConnection = serverSocket.accept();
                    System.out.println("Connection accepted from " + clientConnection.getInetAddress().getHostName());

                    System.out.println("Getting data streams...");
                    PrintWriter output = new PrintWriter(clientConnection.getOutputStream(), true);
                    BufferedReader input = new BufferedReader(new InputStreamReader(clientConnection.getInputStream()));

                    Thread.sleep(3000);
                    output.println("Connected to simple Java server.");

                    String clientMessage = input.readLine();
                    System.out.println("Client said >>> " + clientMessage);

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        clientConnection.close();
                    }
                }

            } catch (IOException ioe) {
                System.out.println("\n--- Cannot open server ---\n");
                ioe.printStackTrace();
            }
    }
}
