import java.io.*;
import java.net.Socket;

public class SimpleClient {
    public static void main(String[] args) {
        /*
        Connect to server
        Receive data
        Send data

         */
        Socket serverConnection = null;
        PrintWriter output = null; //CLIENT FOR TEXT
        BufferedReader input = null;
//        ObjectOutputStream output = null;
//        ObjectInputStream input = null;

        try {
            serverConnection = new Socket("localhost",10001);
            output = new PrintWriter(serverConnection.getOutputStream(), true); //CLIENT FOR TEXT
            input = new BufferedReader(new InputStreamReader(serverConnection.getInputStream()));
//            output = new ObjectOutputStream(serverConnection.getOutputStream());
//            input = new ObjectInputStream(serverConnection.getInputStream());

//            String serverMessage = input.readLine(); //CLIENT FOR TEXT
            String serverMessage = null;
            try {
                serverMessage = (String) input.readLine();
                System.out.println("Server said >>> " + serverMessage);

                output.println("Hello from the client."); //CLIENT FOR TEXT


        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                input.close();
                output.close();
                serverConnection.close();
            } catch (IOException|NullPointerException e) {
                e.printStackTrace();
            }
        }
    }
}
