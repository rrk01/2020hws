object Quine {
    @JvmStatic
    fun main(args: Array<String>) {
        val q = 34.toChar() // Quotation mark character
        val l = arrayOf( // Array of source code
                "public class Quine",
                "{",
                "  public static void main(String[] args)",
                "  {",
                "    char q = 34;      // Quotation mark character",
                "    String[] l = {    // Array of source code",
                "    ",
                "    };",
                "    for(int i = 0; i < 6; i++)           // Print opening code",
                "        System.out.println(l[i]);",
                "    for(int i = 0; i < l.length; i++)    // Print string array",
                "        System.out.println(l[6] + q + l[i] + q + ',');",
                "    for(int i = 7; i < l.length; i++)    // Print this code",
                "        System.out.println(l[i]);",
                "  }",
                "}")
        for (i in 0..5)  // Print opening code
            println(l[i])
        for (i in l.indices)  // Print string array
            println(l[6] + q + l[i] + q + ',')
        for (i in 7 until l.size)  // Print this code
            println(l[i])
    }
}