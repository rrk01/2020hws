object TestingTheArray {
    @JvmStatic
    fun main(args: Array<String>) {
        val TezList = doubleArrayOf(2.9, 5.9, 6.4, 6.5)
        for (x in TezList.indices) {
            println(TezList[x].toString() + " ")
        }

        // Here I will sum up all the elements
        var Thetotal = 0.0
        for (x in TezList.indices) {
            Thetotal += TezList[x]
        }
        println("Here is the total of the array: $Thetotal")
        // Finding the largest element
        var maximum = TezList[0]
        for (x in 1 until TezList.size) {
            if (TezList[x] > maximum) maximum = TezList[x]
        }
        println("The Maximum value of the array is $maximum")
    }
}