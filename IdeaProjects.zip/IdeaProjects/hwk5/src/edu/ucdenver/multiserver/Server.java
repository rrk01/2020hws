package edu.ucdenver.multiserver;

public class Server {
}
