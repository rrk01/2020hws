package edu.ucdenver.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server implements Runnable{
    private int port;
    private int backlog;

    public Server(int port, int backlog) {
        this.port = port;
        this.backlog = backlog;
    }

    @Override
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(port, backlog);
            Socket clientConnection = null;

            while(true) {
                try {
                    System.out.println("Waiting for connection...");
                    clientConnection = serverSocket.accept();
                    System.out.println("Connection accepted from " + clientConnection.getInetAddress().getHostName());

                    System.out.println("Getting data streams...");
                    PrintWriter output = new PrintWriter(clientConnection.getOutputStream(), true);
                    BufferedReader input = new BufferedReader(new InputStreamReader(clientConnection.getInputStream()));

                    Thread.sleep(3000);
                    output.println("Connected to simple Java server.");

                    String clientMessage = input.readLine();
                    System.out.println("Client said >>> " + clientMessage);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    clientConnection.close();
                }
            }

        } catch (IOException ioe) {
            System.out.println("\n--- Cannot open server ---\n");
            ioe.printStackTrace();
        }
    }

}
