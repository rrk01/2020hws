package edu.ucdenver.morse;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.ArrayList;

public class Morse {
    private HashMap<String, String> encoder = new HashMap<String, String>();
    private HashMap<String, String> decoder = new HashMap<String, String>();

    public Morse() {
        encoder.put("A",".-="); encoder.put("B","-...="); encoder.put("C","-.-.=");
        encoder.put("D","-..="); encoder.put("E",".="); encoder.put("F","..-.=");
        encoder.put("G","--.="); encoder.put("H","....="); encoder.put("I","..=");
        encoder.put("J",".---="); encoder.put("K","-.-="); encoder.put("L",".-..=");
        encoder.put("M","--="); encoder.put("N","-.="); encoder.put("O","---=");
        encoder.put("P",".--.="); encoder.put("Q","--.-="); encoder.put("R",".-.=");
        encoder.put("S","...="); encoder.put("T","-="); encoder.put("U","..-=");
        encoder.put("V","...-="); encoder.put("W","..-="); encoder.put("X","-..-=");
        encoder.put("Y","-.--="); encoder.put("Z","--..="); encoder.put(" ", " ");

        decoder.put(".-","A"); decoder.put("-...","B"); decoder.put("-.-.", "C");
        decoder.put("-..","D"); decoder.put(".","E"); decoder.put("..-.","F");
        decoder.put("--.","G"); decoder.put("....","H"); decoder.put("..","I");
        decoder.put(".---","J"); decoder.put("-.-","K"); decoder.put(".-..","L");
        decoder.put("--","M"); decoder.put("-.","N"); decoder.put("---","O");
        decoder.put(".--.","P"); decoder.put("--.-","Q"); decoder.put(".-.","R");
        decoder.put("...","S"); decoder.put("-","T"); decoder.put("..-","U");
        decoder.put("...-","V"); decoder.put(".--", "W"); decoder.put("-..-","X");
        decoder.put("-.--","Y"); decoder.put("--..","Z"); decoder.put(" ", " ");
    }

    public String encode(String input) {
        String output = "";
        for(int i = 0; i < input.length(); i++)
            output += encoder.get(String.valueOf(input.charAt(i)).toUpperCase());
        return output;
    }
    
    public String decode(String input) {
        String output = "";
        String[] inputArr = input.split("=",-1);
        ArrayList<String> inputArrWithSpaces = new ArrayList<String>();
        for(int i = 0; i < inputArr.length - 1; i++) {
            if(inputArr[i].contains(" ")) {
                inputArrWithSpaces.add(" ");
                inputArrWithSpaces.add(inputArr[i].substring(1));
            }else{
                inputArrWithSpaces.add(inputArr[i]);
            }
        }
        for(int i = 0; i < inputArrWithSpaces.size(); i ++) {
            output += decoder.get(inputArrWithSpaces.get(i));
        }
        return output;
    }

    public static void main(String args[]) {
        Morse morse = new Morse();
        System.out.println(morse.encode("hello world"));
        System.out.println(morse.decode("....=.=.-..=.-..=---= .--=---=.-.=.-..=-..="));

        Socket serverConnection = null;
        PrintWriter output = null; //CLIENT FOR TEXT
        BufferedReader input = null;
    }
}